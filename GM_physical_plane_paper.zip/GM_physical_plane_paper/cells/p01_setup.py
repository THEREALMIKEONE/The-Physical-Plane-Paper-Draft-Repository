# ============================================================
# The Physical Plane — a five-coordinate (x,y,z,t,S) analysis
# of Morfs, Selectors and the Law of the Dark   (GM v3)
# Part 0: Setup, data, result registry
#
# Rules this version follows:
#   * No result is hardcoded. Every PASS/FAIL comes from a computation.
#   * Every test has a pass rule written BEFORE the number is computed.
#   * Results are labelled by kind:
#       DERIVED     — a symbolic identity of the geometry (checked, not assumed)
#       TEST        — data can falsify the GM claim
#       MEASUREMENT — a number measured once from data and then held fixed
#       CONSTRAINT  — data bound a GM parameter (no pass/fail)
#       DIAGNOSTIC  — a useful computed number with no pass/fail rule
#       PROPOSED    — a prediction stated here, not yet tested
#       SUPERSEDED  — an earlier formulation, kept with its pre-set rule and outcome
#   * Nothing computed is discarded: every check in the code is recorded.
#   * Published summary numbers are typed in with their citation.
# ============================================================
import os, sys, json, math, zipfile, hashlib, datetime, urllib.request
from pathlib import Path
import numpy as np

IN_COLAB = "google.colab" in sys.modules
if IN_COLAB:
    try:
        from google.colab import drive
        drive.mount("/content/drive")
        ROOT = Path("/content/drive/MyDrive/GM_physical_plane_paper")
    except Exception:
        ROOT = Path("GM_physical_plane_paper")
else:
    ROOT = Path(os.environ.get("GM_ROOT", "."))

DATA = ROOT / "data"
RES  = ROOT / "results"
for d in (DATA, DATA / "sparc", DATA / "clusters", RES):
    d.mkdir(parents=True, exist_ok=True)

# ── Data sources (only what the tests actually use) ─────────
PP = ("https://raw.githubusercontent.com/PantheonPlusSH0ES/DataRelease/main/"
      "Pantheon%2B_Data/4_DISTANCES_AND_COVAR/")
SOURCES = {
    "sparc_rotmod": (["https://zenodo.org/records/16284118/files/Rotmod_LTG.zip",
                      "https://zenodo.org/records/16284118/files/Rotmod_LTG.zip?download=1",
                      "https://astroweb.case.edu/SPARC/Rotmod_LTG.zip",
                      # GitHub mirror (175 files; cross-checked byte-identical with a 2nd mirror)
                      "https://codeload.github.com/carsondowns-cte/Rotmod_LTG/zip/refs/heads/main"],
                     "Rotmod_LTG.zip", True),
    "sparc_table":  (["https://astroweb.case.edu/SPARC/SPARC_Lelli2016c.mrt",
                      "https://raw.githubusercontent.com/amidou/amiga-xmatch/master/SPARC_Lelli2016c.mrt"],
                     "SPARC_Lelli2016c.mrt", True),    # quality flags, distances, inclinations
    "desi_dr2_mean": (["https://raw.githubusercontent.com/CobayaSampler/bao_data/master/desi_bao_dr2/desi_gaussian_bao_ALL_GCcomb_mean.txt"],
                      "DESI_DR2_BAO_mean.txt", True),  # DESI DR2 (2025) BAO, Cobaya data release
    "desi_dr2_cov":  (["https://raw.githubusercontent.com/CobayaSampler/bao_data/master/desi_bao_dr2/desi_gaussian_bao_ALL_GCcomb_cov.txt"],
                      "DESI_DR2_BAO_cov.txt", True),
    "boss_fs8_mean": (["https://raw.githubusercontent.com/CobayaSampler/bao_data/master/sdss_DR12Consensus_final.dat"],
                      "BOSS_DR12_consensus_final.dat", True),  # Alam+17 final consensus
    "boss_fs8_cov":  (["https://raw.githubusercontent.com/CobayaSampler/bao_data/master/final_consensus_covtot_dM_Hz_fsig.txt"],
                      "BOSS_DR12_consensus_cov.txt", True),
    "cl_hiflugcs": (["https://raw.githubusercontent.com/robertmonjo/lensing_RAR_KiDS/main/data/external_reference/clusterRAR.dat"],
                    "clusters/clusterRAR.dat", True),       # Li+2023 cluster RAR (via Monjo & Banik 2025)
    "cl_xcop_prof": (["https://raw.githubusercontent.com/robertmonjo/lensing_RAR_KiDS/main/data/external_reference/xcop_profiles.txt"],
                    "clusters/xcop_profiles.txt", True),     # Eckert+2022 X-COP mass and gas profiles (via Monjo 2025)
    "pantheon_dat": ([PP + "Pantheon%2BSH0ES.dat"], "PantheonPlusSH0ES.dat", True),
    "pantheon_cov": ([PP + "Pantheon%2BSH0ES_STAT%2BSYS.cov"],
                     "PantheonPlusSH0ES_STAT+SYS.cov", True),
}

def _sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for ch in iter(lambda: f.read(1 << 16), b""):
            h.update(ch)
    return h.hexdigest()[:16]

def fetch(key):
    urls, fname, required = SOURCES[key]
    dest = DATA / fname
    if dest.exists() and dest.stat().st_size > 100:
        return dest, "cached"
    for u in urls:
        try:
            req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=120) as r, open(dest, "wb") as f:
                f.write(r.read())
            if dest.stat().st_size > 100:
                return dest, "downloaded"
        except Exception as e:
            last = str(e)[:80]
    if dest.exists():
        dest.unlink()
    return None, ("MISSING (required)" if required else "missing (optional)")

print("── Data ──────────────────────────────────────────────")
PROVENANCE = {}
for k in SOURCES:
    p, status = fetch(k)
    PROVENANCE[k] = {"file": SOURCES[k][1], "status": status,
                     "sha256_16": _sha(p) if p else None}
    print(f"  {k:14s} {status:20s} {PROVENANCE[k]['sha256_16'] or ''}")

# unpack SPARC rotation curves
zp = DATA / "Rotmod_LTG.zip"
if zp.exists() and len(list((DATA / "sparc").glob("*_rotmod.dat"))) < 100:
    with zipfile.ZipFile(zp) as z:
        for m in z.namelist():
            if m.endswith("_rotmod.dat"):
                (DATA / "sparc" / Path(m).name).write_bytes(z.read(m))
print(f"  SPARC rotation curves on disk: {len(list((DATA/'sparc').glob('*_rotmod.dat')))}")

# ── Result registry ─────────────────────────────────────────
RESULTS = []
def record(test, kind, claim, value, rule=None, passed=None, note=""):
    """kind: DERIVED | TEST | MEASUREMENT | CONSTRAINT | DIAGNOSTIC | PROPOSED | SUPERSEDED"""
    RESULTS.append(dict(test=test, kind=kind, claim=claim, value=value,
                        rule=rule, passed=passed, note=note))
    tag = {True: "PASS", False: "FAIL", None: kind}[passed]
    print(f"  [{tag}] {test}: {claim} -> {value}")

# Physical constants
C_KMS   = 299792.458                 # km/s
C_SI    = 299792458.0                # m/s
MPC_M   = 3.0856775814913673e22      # m
KPC_M   = 3.0856775814913673e19      # m
YR_S    = 3.15576e7                  # s
H0_SI   = lambda H0: H0 * 1e3 / MPC_M          # s^-1
G_DAG   = lambda H0: C_SI * H0_SI(H0) / (2 * math.pi)   # GM prediction, m/s^2
print(f"\n  g† = cH0/2π : {G_DAG(67.4):.3e} m/s² (H0=67.4)  |  {G_DAG(73.0):.3e} m/s² (H0=73.0)")
