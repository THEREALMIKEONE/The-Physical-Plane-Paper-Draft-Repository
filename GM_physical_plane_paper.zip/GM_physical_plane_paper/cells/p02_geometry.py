# ============================================================
# §3 — The geometry behind the map: theory core (SymPy). Every check is a computation.
#
# I.1–I.4  5D geometry with S a real coordinate (ε = +1, spacelike):
#          ds² = e^{2A(S)} [ -dt² + a(t)² dx⃗² ] + dS²
#          Extrinsic curvature, Gauss–Codazzi constraint, vacuum
#          solutions with bulk vacuum energy Λ5, and the S-dependent
#          4D vacuum energy seen on each S-slice.
# I.5      Holographic identification: S ↔ ln μ (not μ/μ0).
# I.6–I.8  4D effective cosmology actually used in Part II:
#          scalar S(t) with α_S > 0 and one potential V(S),
#          a³ volume factor included, lapse N for the constraint.
# ============================================================
import sympy as sp

print("── §3: theory core ───────────────────────────────")

def einstein_tensor(g, X):
    n = len(X)
    gi = sp.simplify(g.inv())
    Gam = [[[sp.simplify(sum(gi[a, d] * (sp.diff(g[d, b], X[c]) + sp.diff(g[d, c], X[b])
                                          - sp.diff(g[b, c], X[d])) for d in range(n)) / 2)
             for c in range(n)] for b in range(n)] for a in range(n)]
    Ric = sp.zeros(n, n)
    for b in range(n):
        for c in range(n):
            Ric[b, c] = sp.simplify(sum(
                sp.diff(Gam[a][b][c], X[a]) - sp.diff(Gam[a][b][a], X[c])
                + sum(Gam[a][a][d] * Gam[d][b][c] - Gam[a][c][d] * Gam[d][b][a] for d in range(n))
                for a in range(n)))
    R = sp.simplify(sum(gi[i, j] * Ric[i, j] for i in range(n) for j in range(n)))
    G = sp.simplify(Ric - R * g / 2)
    return G, R

t, x, y, z, S = sp.symbols("t x y z S", real=True)
H, k, L5, c0 = sp.symbols("H k Lambda5 c0", real=True)
A = sp.Function("A")(S)
a = sp.Function("a")(t)
X5 = [t, x, y, z, S]

def metric5(A_, a_):
    w = sp.exp(2 * A_)
    return sp.diag(-w, w * a_**2, w * a_**2, w * a_**2, 1)

def metric4(a_):
    return sp.diag(-1, a_**2, a_**2, a_**2)

THEORY = {}

# ── I.1 Extrinsic curvature of S = const slices ─────────────
g5 = metric5(A, a)
h  = g5[:4, :4]
K  = sp.Rational(1, 2) * sp.diff(h, S)              # K_μν = ½ ∂_S h_μν  (Φ = 1)
hi = h.inv()
Kmix = sp.simplify(hi * K)
K_tr = sp.simplify(Kmix.trace())
K_sq = sp.simplify((Kmix * Kmix).trace())
gauss_term = sp.simplify(K_tr**2 - K_sq)
Ap = sp.diff(A, S)
ok = sp.simplify(K - Ap * h) == sp.zeros(4, 4) and sp.simplify(gauss_term - 12 * Ap**2) == 0
THEORY["K"] = {"K_mn": "A'(S) h_mn", "K": str(K_tr), "K2_minus_KK": str(gauss_term)}
record("I.1", "DERIVED", "K_μν = A' h_μν and K² − K_μνK^μν = 12 A'²", str(gauss_term),
       rule="symbolic identity", passed=ok)

# ── I.2 Gauss–Codazzi (Hamiltonian) constraint, verified ────
print("  computing 5D Einstein tensor (warped FRW slices)...")
G5, R5 = einstein_tensor(g5, X5)
_, R4h = einstein_tensor(h.subs(A, sp.Symbol("A0")), [t, x, y, z])   # intrinsic curvature on a slice
R4h = R4h.subs(sp.Symbol("A0"), A)
lhs = 2 * G5[4, 4]
rhs = -R4h + gauss_term
ok = sp.simplify(lhs - rhs) == 0
record("I.2", "DERIVED", "2 G_SS = −R[h] + (K² − K_μνK^μν)  (Gauss–Codazzi, ε=+1)",
       "identity holds" if ok else str(sp.simplify(lhs - rhs)), rule="symbolic identity", passed=ok)

# ── I.3 Flat slices in a bulk with vacuum energy Λ5 ─────────
#   5D field equations  G_AB = −Λ5 g_AB
g_flat = metric5(A, sp.Integer(1))
Gf, Rf = einstein_tensor(g_flat, X5)
eq_SS = sp.simplify(Gf[4, 4] + L5 * g_flat[4, 4])
eq_tt = sp.simplify((Gf[0, 0] + L5 * g_flat[0, 0]) / g_flat[0, 0])
sol_Ap2 = sp.solve(sp.Eq(eq_SS, 0), Ap**2)
THEORY["flat_slices"] = {"SS_equation": str(eq_SS), "A_prime_sq": str(sol_Ap2)}
# warp A = -kS must solve everything with Λ5 = -6k²
A_ads = -k * S
gA = metric5(A_ads, sp.Integer(1))
GA, RA = einstein_tensor(gA, X5)
residual = sp.simplify(GA + (-6 * k**2) * gA)
ok = residual == sp.zeros(5, 5) and sp.simplify(RA + 20 * k**2) == 0
record("I.3", "DERIVED",
       "Flat 4D slices need A'² = −Λ5/6 ⇒ Λ5 < 0: the bulk vacuum is AdS5, Ricci scalar R5 = −20k² < 0",
       f"A'² = {sol_Ap2[0] if sol_Ap2 else '?'};  R5(A=-kS) = {sp.simplify(RA)}",
       rule="A=-kS, Λ5=-6k² solves all 15 components", passed=ok,
       note="This is the precise form of 'Darkness carries negative curvature at every scale layer'.")

# ── I.4 Curved (de Sitter) slices: the S-dependent 4D vacuum energy ──
g_ds = metric5(A, sp.exp(H * t))
Gd, _ = einstein_tensor(g_ds, X5)
eq_SS_ds = sp.simplify(Gd[4, 4] + L5 * g_ds[4, 4])
# proper Hubble rate on slice S: H_eff = H e^{-A};  4D vacuum energy Λ4(S) = 3 H_eff²
Heff2 = sp.solve(sp.Eq(eq_SS_ds, 0), H**2)[0] * sp.exp(-2 * A)
Lam4 = sp.simplify(3 * Heff2)
Lam4_GC = sp.simplify(L5 / 2 + gauss_term / 4)
ok1 = sp.simplify(Lam4 - Lam4_GC) == 0
# exact solution: A = ln[(H/k) sinh(k(c0 - S))] with Λ5 = -6k²
A_dS = sp.log(H / k * sp.sinh(k * (c0 - S)))
gS = metric5(A_dS, sp.exp(H * t))
GS, _ = einstein_tensor(gS, X5)
res = sp.simplify((GS + (-6 * k**2) * gS).applyfunc(lambda e: sp.simplify(e.rewrite(sp.exp))))
ok2 = res == sp.zeros(5, 5)
THEORY["Lambda_eff"] = {"derived": "Λ_eff(S) = Λ5/2 + (K² − K_μνK^μν)/4 = Λ5/2 + 3A'(S)²",
                        "paper_eq3": "Λ_eff = V(S) − ½(K² − K_μνK^μν)",
                        "exact_solution": "A(S) = ln[(H/k) sinh(k(c0−S))], Λ5 = −6k²"}
record("I.4", "DERIVED",
       "4D vacuum energy on slice S: Λ_eff(S) = Λ5/2 + (K² − K_μνK^μν)/4",
       str(Lam4), rule="SS constraint + exact dS-sliced solution", passed=bool(ok1 and ok2),
       note="Same structure as paper Eq.3 — two opposing terms — with the negative part carried by the bulk "
            "(Darkness, Λ5 < 0) and a positive gradient term. Λ_eff → 0 where A'² → k².")

# ── I.5 Holographic identification S ↔ ln μ ────────────────
#   A field mode of energy E0 at S=0 has proper energy E0 e^{-A(S)} on slice S.
E0 = sp.Symbol("E0", positive=True)
mu_of_S = E0 * sp.exp(-A_ads)
S_of_mu = sp.solve(sp.Eq(sp.Symbol("mu", positive=True), mu_of_S), S)[0]
ok = sp.simplify(sp.diff(S_of_mu, sp.Symbol("mu", positive=True)) * sp.Symbol("mu", positive=True) - 1 / k) == 0
record("I.5", "DERIVED", "In the AdS bulk the scale coordinate is logarithmic: S = (1/k) ln(μ/μ0)",
       str(S_of_mu), rule="μ dS/dμ = 1/k", passed=ok,
       note="Replace the paper's S = μ/μ0 with S = ln(μ/μ0)/k. Then d/dS = k·d/d ln μ, which is exactly the RG derivative.")

# ── I.6 4D effective cosmology (minisuperspace) ─────────────
N = sp.Function("N")(t)
s_f = sp.Function("S")(t)
alpha, G_N = sp.symbols("alpha_S G", positive=True)
V0, S0 = sp.symbols("V0 S0", positive=True)
V = V0 * sp.exp(-s_f / S0)                       # ONE potential, used everywhere
L = N * a**3 * (-3 / (8 * sp.pi * G_N) * sp.diff(a, t)**2 / (a**2 * N**2)
                + alpha * sp.diff(s_f, t)**2 / (2 * N**2) - V)
def EL(Lag, q):
    return sp.simplify(sp.diff(Lag, q) - sp.diff(sp.diff(Lag, sp.diff(q, t)), t))
E_N = sp.simplify(EL(L, N).subs(N, 1).doit())
E_S = sp.simplify(EL(L, s_f).subs(N, 1).doit())
E_a = sp.simplify(EL(L, a).subs(N, 1).doit())
rho = alpha * sp.diff(s_f, t)**2 / 2 + V
Hub = sp.diff(a, t) / a
friedmann = sp.simplify(E_N / a**3)       # should be ∝ H² − (8πG/3)ρ
ok_f = sp.simplify(friedmann + 3 / (8 * sp.pi * G_N) * Hub**2 - rho) == 0 or \
       sp.simplify(friedmann - (3 / (8 * sp.pi * G_N) * Hub**2 - rho)) == 0
kg = sp.simplify(E_S / a**3)
ok_kg = sp.simplify(kg + alpha * (sp.diff(s_f, t, 2) + 3 * Hub * sp.diff(s_f, t)) + sp.diff(V, s_f)) == 0 or \
        sp.simplify(kg - alpha * (sp.diff(s_f, t, 2) + 3 * Hub * sp.diff(s_f, t)) - sp.diff(V, s_f)) == 0
coupled = E_S.has(a) and E_N.has(s_f)
record("I.6", "DERIVED",
       "Friedmann H² = (8πG/3)(α_S Ṡ²/2 + V) and α_S(S̈ + 3HṠ) + V'(S) = 0; S and a(t) coupled",
       f"friedmann={ok_f}, klein-gordon={ok_kg}, coupled={coupled}",
       rule="all three true", passed=bool(ok_f and ok_kg and coupled),
       note="The v1 Part I Lagrangian had no a³ factor, so S never sourced the expansion.")

# Bianchi consistency: the constraint is preserved by the dynamics
Sdd = sp.solve(E_S, sp.diff(s_f, t, 2))[0]
add = sp.solve(E_a, sp.diff(a, t, 2))[0]
Cst = Hub**2 - 8 * sp.pi * G_N / 3 * rho
dC = sp.diff(Cst, t).subs({sp.diff(s_f, t, 2): Sdd, sp.diff(a, t, 2): add})
ratio = sp.simplify(dC / Cst)
ok = not ratio.has(sp.zoo) and sp.simplify(dC.subs(sp.diff(a, t), sp.sqrt(8 * sp.pi * G_N / 3 * rho) * a)) == 0
record("I.7", "DERIVED", "Friedmann constraint preserved by the equations of motion",
       f"dC/dt = ({ratio})·C", rule="dC/dt ∝ C", passed=bool(ok))

# ── I.8 Equation of state of the scalar sector: 1 + w ≥ 0 ────
Sd = sp.Symbol("Sdot", real=True); Vv = sp.Symbol("V", positive=True)
rho_s = alpha * Sd**2 / 2 + Vv
p_s = alpha * Sd**2 / 2 - Vv
one_plus_w = sp.simplify(1 + p_s / rho_s)
ok = sp.simplify(one_plus_w - alpha * Sd**2 / rho_s) == 0
record("I.8", "DERIVED",
       "Scalar-sector equation of state: 1 + w = α_S Ṡ²/ρ ≥ 0 (ghost-free scalar cannot be phantom)",
       str(one_plus_w), rule="symbolic identity", passed=ok,
       note="Applies to the 4D scalar sector of the PSM action (paper Sec. 5) only; the 5D geometry itself can give w < −1.")



# ============================================================
# §3 (cont.) — the Law of the Dark on the slices, junction, the floor
#
# I.11  Λ_eff ∝ μ² along the exact solution
# I.12  Matter relaxes Darkness: Israel junction ⇒ brane Friedmann equation
# I.13  S-floor = where the quantum (Compton) and black-hole lines meet
# ============================================================
print("── §3: Λ_eff scaling, junction, floor ─────────────")

# ── I.11 ────────────────────────────────────────────────────
Hs, E0s = sp.symbols("H E0", positive=True)
A_ex = sp.log(Hs / k * sp.sinh(k * (c0 - S)))
Lam_slice = 3 * Hs**2 * sp.exp(-2 * A_ex)          # proper 4D vacuum curvature on slice S
mu_slice = E0s * sp.exp(-A_ex)                     # proper energy scale on slice S
ratio = sp.simplify(Lam_slice / mu_slice**2)
ok = not ratio.has(S)
Mp_eV = 2.435e27                                   # reduced Planck mass (eV)
H0_eV0 = 100 * 0.6736 * 1e3 / MPC_M * 6.582119569e-16
gap = (Mp_eV / H0_eV0)**2
record("I.11", "DERIVED",
       "Along the exact solution the slice vacuum curvature scales as Λ_eff ∝ μ², so ρ_vac ~ M_p²μ² (not μ⁴)",
       f"Λ_eff/μ² = {ratio} (independent of S); floor-to-cosmic ratio (M_p/H0)² = {gap:.2e}",
       rule="S-independent ratio", passed=bool(ok),
       note="With μ = M_p at the floor and μ = H0 at the cosmic slice, the vacuum falls by (M_p/H0)², the 10¹²⁰ gap. "
            "μ = H0 at the cosmic slice is an identification of where our slice sits, not a derivation.")

# ── I.12 ────────────────────────────────────────────────────
#   Israel junction for a Z2-symmetric slice carrying energy (tension σ + matter ρ):
#   [K_μν] − h_μν[K] = −κ² S_μν,  K_μν = A' h_μν,  S_μν = −(σ+ρ) h_μν (static limit)
kap, sig, rho_b = sp.symbols("kappa sigma rho", positive=True)
jump = sp.Symbol("J")                               # [A'] across the slice
eq = sp.Eq(jump - 4 * jump, -kap**2 * (sig + rho_b))   # (h_μν coefficient)
J = sp.solve(eq, jump)[0]
Ap_side = -J / 2                                    # Z2: A'(0±) = ∓J/2  → |A'| = |J|/2
H2_brane = sp.expand(L5 / 6 + Ap_side**2)            # from I.4: H_eff² = A'² + Λ5/6
lin = sp.simplify(H2_brane.coeff(rho_b, 1))
quad = sp.simplify(H2_brane.coeff(rho_b, 2))
const = sp.simplify(H2_brane.subs(rho_b, 0))
G4 = sp.solve(sp.Eq(lin, 8 * sp.pi * sp.Symbol("G4") / 3), sp.Symbol("G4"))[0]
THEORY["brane_friedmann"] = {"H2": str(H2_brane), "G4": str(G4), "rho2_coeff": str(quad), "Lambda4_over_3": str(const)}
record("I.12", "DERIVED",
       "Matter relaxes Darkness: energy on a slice raises A'², cancelling the negative bulk term; "
       "gives H² = Λ5/6 + κ⁴(σ+ρ)²/36",
       f"G4 = {G4};  ρ² term coeff = {quad};  Λ4/3 = {const}",
       rule="Israel junction (static shortcut) + I.4; matches full BDL result", passed=bool(sp.simplify(H2_brane - (L5/6 + kap**4*(sig+rho_b)**2/36)) == 0),
       note="Standard brane-world result (Binétruy–Deffayet–Langlois 2000). Flat vacuum needs κ⁴σ² = −6Λ5: the fine-tuning still owed.")

# ── I.13 ────────────────────────────────────────────────────
hb, cc, Gn, Mm = sp.symbols("hbar c G M", positive=True)
Mfloor = sp.solve(sp.Eq(hb / (Mm * cc), 2 * Gn * Mm / cc**2), Mm)[0]
Rfloor = sp.simplify(hb / (Mfloor * cc))
lP = sp.sqrt(hb * Gn / cc**3)
record("I.13", "DERIVED", "S-floor: the quantum line R = ħ/Mc meets the black-hole line R = 2GM/c² at the Planck scale",
       f"M = {Mfloor}, R = {sp.simplify(Rfloor/lP)}·ℓ_P", rule="symbolic", passed=bool(sp.simplify(Rfloor / lP - sp.sqrt(2)) == 0))
rhoc = sp.symbols("rho_c", positive=True)
Hh = sp.symbols("H_0", positive=True)
RH = cc / Hh
MH = sp.Rational(4, 3) * sp.pi * (3 * Hh**2 / (8 * sp.pi * Gn)) * RH**3
ident = sp.simplify(2 * Gn * MH / cc**2 - RH) == 0
record("I.13b", "DIAGNOSTIC", "S-ceiling: the universe sits exactly on its own black-hole line",
       "2GM_H/c² = c/H0" if ident else "no", passed=None,
       note="This is an identity of flat Friedmann cosmology (critical density), not evidence for GM. State it as such.")
# ── I.14 Gravitational waves on the slice ──────────────────
#   Tensor perturbation h_xy(t,z,S) on the AdS warped background (A = −kS, Λ5 = −6k²);
#   linearised vacuum equation R_xy = (2/3)Λ5 g_xy at first order. The S-independent
#   (zero) mode is the 4D graviton: it must obey □h = 0, i.e. travel at exactly c.
def _gw_zero_mode():
    tt, xx, yy, zz, SS = sp.symbols("t x y z S", real=True)
    kk = sp.Symbol("k", positive=True); ep = sp.Symbol("epsilon")
    hh = sp.Function("h")(tt, zz, SS); ww = sp.exp(-2 * kk * SS)
    gg = sp.Matrix(sp.diag(-ww, ww, ww, ww, 1)); gg[1, 2] = gg[2, 1] = ww * ep * hh
    XX = [tt, xx, yy, zz, SS]; nn = 5
    gi = gg.inv().applyfunc(lambda e: sp.series(e, ep, 0, 2).removeO())
    D = lambda e, i: sp.diff(e, XX[i])
    Gm = [[[sp.series(sp.expand(sum(gi[a_, d_] * (D(gg[d_, b_], c_) + D(gg[d_, c_], b_) - D(gg[b_, c_], d_))
                                    for d_ in range(nn)) / 2), ep, 0, 2).removeO()
            for c_ in range(nn)] for b_ in range(nn)] for a_ in range(nn)]
    R12 = sum(D(Gm[a_][1][2], a_) - D(Gm[a_][1][a_], 2)
              + sum(Gm[a_][a_][d_] * Gm[d_][1][2] - Gm[a_][2][d_] * Gm[d_][1][a_] for d_ in range(nn)) for a_ in range(nn))
    eq = sp.simplify(sp.expand(R12 + 4 * kk**2 * gg[1, 2]).coeff(ep, 1))
    f0 = sp.Function("f")(tt, zz)
    zero = sp.simplify(eq.subs(hh, f0).doit())
    wave = sp.diff(f0, tt, 2) - sp.diff(f0, zz, 2)
    return eq, sp.simplify(zero / wave)
_gw_eq, _gw_ratio = _gw_zero_mode()
GW_LUMINAL = bool(_gw_ratio.is_number and _gw_ratio != 0)
record("I.14", "DERIVED", "Gravitational waves on the slice: the graviton zero mode obeys □h = 0 (speed exactly c)",
       f"zero-mode equation ∝ (∂t² − ∂z²) h, factor {_gw_ratio}", rule="symbolic", passed=GW_LUMINAL,
       note="Linearised 5D vacuum equation for a tensor mode on the AdS warped background; the S-independent mode is the 4D graviton.")
(RES / "part1_theory.json").write_text(json.dumps(THEORY, indent=2))


# ============================================================
# §3 — The sign flip at scale boundaries
#
# Framework: each tier's stable structures become the medium
# (Darkness) of the next tier; at the S-ceiling "our physics becomes the
# Darkness of a larger-scale system". In the 5D geometry this has two exact forms:
#
#   F1  Across a slice that carries energy, the extrinsic curvature flips sign:
#       K_μν(S→0+) = −K_μν(S→0−)   (Z2 junction, I.12)
#       — the layer bends the geometry one way below it and the other way above it.
#   F2  The vacuum seen ON a slice, Λ4 = Λ5/2 + κ⁴σ²/12, changes sign at a
#       critical energy content σ_c = √(−6Λ5)/κ²:
#         σ < σ_c → Λ4 < 0 (Darkness wins: AdS-like layer)
#         σ = σ_c → Λ4 = 0 (balance: flat layer)
#         σ > σ_c → Λ4 > 0 (matter overshoots: expanding layer)
# ============================================================
print("── §3: the sign flip ───────────────────────────")
# I.12: [A'] = J = −κ²(σ+ρ)/3 ; Z2: A'(0−) = −J/2, A'(0+) = +J/2
A_left, A_right = -J / 2, J / 2
K_left, K_right = A_left, A_right               # K_μν = A' h_μν (coefficient)
ok_F1 = sp.simplify(K_left + K_right) == 0 and sp.simplify(K_right - K_left - J) == 0
record("F1", "DERIVED", "Sign flip of the bending: across a slice carrying energy, K_μν reverses sign",
       f"K(0−) = {sp.simplify(K_left)}·h,  K(0+) = {sp.simplify(K_right)}·h", rule="Z2 junction (I.12)", passed=bool(ok_F1),
       note="A layer of matter bends the scale-geometry one way below it and the opposite way above it.")

Lam4 = L5 / 2 + kap**4 * sig**2 / 12
k_ = sp.Symbol("k", positive=True)
Lam4_k = sp.simplify(Lam4.subs(L5, -6 * k_**2))
sc = sp.solve(sp.Eq(Lam4_k, 0), sig)
sc_pos = [v for v in sc if sp.simplify(v).is_positive]
signs = {lab: sp.sign(sp.simplify(Lam4_k.subs(sig, val))) for lab, val in
         (("below", sc_pos[0] / 2), ("at", sc_pos[0]), ("above", 2 * sc_pos[0]))}
ok_F2 = signs == {"below": -1, "at": 0, "above": 1}
record("F2", "DERIVED", "Sign flip of the vacuum: a layer's Λ4 flips sign at a critical energy content σ_c",
       f"σ_c = {sc_pos[0]} (with Λ5 = −6k²); sign below/at/above = {signs['below']}/{signs['at']}/{signs['above']}",
       rule="symbolic", passed=bool(ok_F2),
       note="Darkness wins below σ_c (negative layer vacuum), matter wins above (positive, expanding layer).")

# Where is OUR layer? measured Λ4 > 0 and tiny  ⇒  just above the flip.
#   (σ − σ_c)/σ_c ≈ Λ4 / (κ⁴σ_c²/6) = ρ_Λ/σ_c   (using 8πG4 = κ⁴σ/6)
rho_L_eV4 = 0.7 * 3 * (100 * 0.68 * 1e3 / MPC_M * 6.582119569e-16)**2 * 2.435e27**2   # ρ_Λ in eV⁴
s4 = 5.5e12                                             # σ^(1/4) lower bound if the 5th dimension is literal (eV)
frac = rho_L_eV4 / s4**4
record("F3", "DIAGNOSTIC", "Where our layer sits relative to the flip (literal-5D reading)",
       f"(σ − σ_c)/σ_c ≈ {frac:.1e} for σ^(1/4) = {s4/1e12:.1f} TeV",
       note="Our small positive vacuum is the small difference between the bulk term and the layer's energy content. "
            "The cosmological-constant tuning is moved into the geometry, not removed. Applies only if the fifth dimension "
            "is literal (D1); in the holographic reading σ has no measured value.")
