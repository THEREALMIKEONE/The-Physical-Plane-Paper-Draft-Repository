# ============================================================
# §2 — Physical Selector, Morf tiers, physical replicators
#
# Coordinates: S = ln(μ/μ0) with μ = ħc/R (the energy scale of a structure
# of size R), so S runs from the floor (Planck) to the ceiling (Hubble).
# Mapping, not testing: standard physics already fixes these boundaries,
# so none of this can fail. Labelled DIAGNOSTIC. The open problem is for GM
# to predict one number here that standard physics does not.
#
# Catalog: textbook masses and characteristic radii (order of magnitude).
# ============================================================
HBAR, G_SI = 1.054571817e-34, 6.67430e-11
MSUN = 1.989e30
CATALOG = [  # name, tier, mass [kg], radius [m], replicator?
    ("proton",               "hadron",     1.673e-27, 8.4e-16,  False),
    ("U-238 nucleus",        "nucleus",    3.95e-25,  7.4e-15,  False),
    ("hydrogen atom",        "atom",       1.674e-27, 5.29e-11, False),
    ("water molecule",       "molecule",   2.99e-26,  1.4e-10,  False),
    ("ribozyme (self-replicating RNA)", "molecule", 1.0e-22, 5.0e-9, True),
    ("ribosome",             "molecule",   4.2e-21,   1.25e-8,  False),
    ("virus (~100 nm)",      "molecule",   1.0e-18,   5.0e-8,   False),
    ("E. coli",              "cell",       1.0e-15,   1.0e-6,   True),
    ("human",                "organism",   70.0,      0.9,      True),
    ("blue whale",           "organism",   1.5e5,     15.0,     True),
    ("giant sequoia",        "organism",   2.0e6,     45.0,     True),
    ("Moon",                 "planet",     7.35e22,   1.737e6,  False),
    ("Earth",                "planet",     5.97e24,   6.371e6,  False),
    ("Jupiter",              "planet",     1.898e27,  6.99e7,   False),
    ("Sun",                  "star",       MSUN,      6.96e8,   False),
    ("Sirius B (white dwarf)","star",      2.0e30,    5.8e6,    False),
    ("neutron star",         "star",       2.8e30,    1.2e4,    False),
    ("10 Msun black hole",   "black hole", 10 * MSUN, 2.95e4,   False),
    ("Sgr A*",               "black hole", 4.3e6 * MSUN, 1.27e10, False),
    ("globular cluster",     "galaxy",     1e6 * MSUN, 3.1e17,  False),
    ("Milky Way (incl. halo)","galaxy",    1.5e12 * MSUN, 1.5e21, False),
    ("Coma cluster",         "cluster",    1e15 * MSUN, 3.0e22,  False),
]

lP_m = math.sqrt(HBAR * G_SI / C_SI**3)
R_floor = math.sqrt(2) * lP_m                         # I.13
R_ceil = C_SI / H0_SI(67.4)
S_of = lambda R: math.log(R / R_floor)               # ln(μ_floor/μ): 0 at floor, grows toward cosmic scales
S_ceil = S_of(R_ceil)
print("── §2: Selector, Morfs, replicators ──────────────")
print(f"  S-floor R = {R_floor:.2e} m (S=0)   S-ceiling R = c/H0 = {R_ceil:.2e} m (S={S_ceil:.1f} e-folds)")
rows, violations = [], []
for name, tier, M, R, rep in CATALOG:
    Rc = HBAR / (M * C_SI)          # quantum (Compton) boundary
    Rs = 2 * G_SI * M / C_SI**2     # black-hole boundary
    inside = R >= 0.99 * max(Rc, Rs)
    if not inside:
        violations.append(name)
    rho = M / (4 / 3 * math.pi * R**3)
    rows.append({"name": name, "tier": tier, "M": M, "R": R, "S": S_of(R),
                 "S_frac": S_of(R) / S_ceil, "log_rho": math.log10(rho),
                 "R_over_Rs": R / Rs, "R_over_Rc": R / Rc, "replicator": rep})
for rw in rows:
    print(f"    {rw['name']:32s} S={rw['S']:6.1f} ({100*rw['S_frac']:4.1f}%)  log ρ={rw['log_rho']:6.1f}  "
          f"R/R_bh={rw['R_over_Rs']:.1e}  R/R_q={rw['R_over_Rc']:.1e}")
record("S8a", "DIAGNOSTIC", "Physical Selector: every catalogued structure lies inside the quantum/black-hole triangle",
       f"{len(rows) - len(violations)}/{len(rows)} inside" + (f" (on boundary: {violations})" if violations else ""),
       note="Cannot fail in standard physics — it maps the Selector, it does not test GM.")

# Morf tiers: structures cluster on a few density lines (nuclear, condensed matter, ...)
dens = {}
for rw in rows:
    if rw["tier"] in ("black hole",):
        continue
    dens.setdefault(rw["tier"], []).append(rw["log_rho"])
nuclear = [rw["log_rho"] for rw in rows if rw["tier"] in ("hadron", "nucleus") or rw["name"] == "neutron star"]
condensed = [rw["log_rho"] for rw in rows if rw["tier"] in ("cell", "organism", "planet") or rw["name"] in ("water molecule",)]
record("S9a", "DIAGNOSTIC", "Morf tiers sit on few density lines (nuclear vs condensed matter)",
       f"nuclear log ρ = {np.mean(nuclear):.1f}±{np.std(nuclear):.1f}; condensed log ρ = {np.mean(condensed):.1f}±{np.std(condensed):.1f} (kg/m³)",
       note="Each line is set by the force that dominates that S-range (strong vs electromagnetic): "
            "the effective-field-theory tower read along S.")
reps = [rw for rw in rows if rw["replicator"]]
w_lo, w_hi = min(r_["S"] for r_ in reps), max(r_["S"] for r_ in reps)
record("S10a", "DIAGNOSTIC", "Physical-replicator S-window (catalogued replicators)",
       f"S = {w_lo:.1f} → {w_hi:.1f} e-folds = {100*(w_hi-w_lo)/S_ceil:.0f}% of floor-to-ceiling, centred at {100*(w_lo+w_hi)/2/S_ceil:.0f}%",
       note=f"Descriptive. The midpoint of the S-range is R = {R_floor*math.exp(S_ceil/2):.0e} m (cell scale). "
            "Whether the window's central position means anything needs a GM prediction; otherwise it is numerology.")
(RES / "sections08_10_selector.json").write_text(json.dumps({"S_ceil": S_ceil, "rows": rows}, indent=2))


# ============================================================
# §2 — The chain: vacuum along S → forces along S → Selector →
# Morf tiers → replicators, with every structure as a vector in (x,y,z,t,S)
#
# Map     Vector analysis: each structure = (centre in x,y,z; time scale t; scale S),
#      plus its S-extent (how many e-folds from constituents to whole) and the
#      number of spatial axes it spans (n: 1 filament, 2 disc, 3 sphere).
# Forces  Force layers: Standard-Model couplings run along S (one-loop RGEs);
#      gravity's dimensionless strength α_G(μ) = (μ/M_P)² grows with S⁻¹.
# Tiers   Tier boundaries PREDICTED from the couplings, then checked against the catalog.
# Window  The replicator window predicted from the same boundaries.
#
# Honesty: §6–10 reproduce standard physics (Press & Lightman 1983 style
# order-of-magnitude scalings) read as S-layer boundaries. They test that the
# chain is consistent; the only GM-specific input is the galaxy tier (g†, below).
# Rule for order-of-magnitude predictions: within a factor 3 (0.5 dex), fixed in advance.
# ============================================================
print("── §2: the chain ──────────────────────────")
ME, MP_KG = 9.1093837e-31, 1.67262192e-27
ALPHA0 = 1 / 137.035999
GEV_J = 1.602176634e-10
HBARC_GEVM = 1.973269804e-16                       # ħc in GeV·m
def R_of_mu(mu_GeV): return HBARC_GEVM / mu_GeV     # size ↔ energy scale

# ── vector analysis ─────────────────────────────────────
NDIM = {"proton": 3, "U-238 nucleus": 3, "hydrogen atom": 3, "water molecule": 3,
        "ribozyme (self-replicating RNA)": 3, "ribosome": 3, "virus (~100 nm)": 3, "E. coli": 3,
        "human": 3, "blue whale": 3, "giant sequoia": 1, "Moon": 3, "Earth": 3, "Jupiter": 3, "Sun": 3,
        "Sirius B (white dwarf)": 3, "neutron star": 3, "10 Msun black hole": 3, "Sgr A*": 3,
        "globular cluster": 3, "Milky Way (incl. halo)": 2, "Coma cluster": 3}
CONSTITUENT_R = {"hadron": 1e-18, "nucleus": 8.4e-16, "atom": 8.4e-16, "molecule": 5.29e-11, "cell": 1e-8,
                 "organism": 1e-6, "planet": 1e-10, "star": 1e-15, "black hole": None, "galaxy": 6.96e8, "cluster": 1.5e21}
VEC = []
for rw in rows:
    tdyn = math.sqrt(rw["R"]**3 / (G_SI * rw["M"]))          # free-fall time: the structure's own clock
    rc = CONSTITUENT_R.get(rw["tier"])
    n = NDIM.get(rw["name"], 3)
    VEC.append({"name": rw["name"], "S": rw["S"], "t_dyn_s": tdyn,
                "S_extent": math.log(rw["R"] / rc) if rc else None, "n_axes": n})
print("    structure                         S     ΔS(extent)  log t_dyn[s]  n")
for v in VEC:
    ext = f"{v['S_extent']:5.1f}" if v["S_extent"] is not None else "  —  "
    print(f"    {v['name']:32s} {v['S']:5.1f}   {ext}      {math.log10(v['t_dyn_s']):6.1f}     {v['n_axes']}")
record("V3a", "DIAGNOSTIC", "Physical plane as vectors: every catalogued structure placed in (x,y,z,t,S)",
       f"{len(VEC)} structures; S from {min(v['S'] for v in VEC):.0f} to {max(v['S'] for v in VEC):.0f} e-folds",
       note="t = own free-fall time; S-extent = e-folds from constituents to whole; n = axes spanned.")

# ── force layers: one-loop running along S ─────────────
MZ, aem_inv_MZ, s2w, as_MZ = 91.1876, 127.952, 0.23121, 0.1180
a1i = (3 / 5) * (1 - s2w) * aem_inv_MZ        # GUT-normalised U(1): α1⁻¹ = (3/5) cos²θ/α
a2i = s2w * aem_inv_MZ
b_SM = (41 / 10, -19 / 6)
def alpha_s(mu):
    """one-loop α_s with quark thresholds (mb = 4.18, mc = 1.27 GeV)"""
    inv = 1 / as_MZ
    seg = [(MZ, 4.18, 5), (4.18, 1.27, 4), (1.27, 0.0, 3)]
    if mu >= MZ:                                    # nf = 5 up to the top mass, 6 above
        if mu <= 172.7:
            return 1 / (inv + (11 - 10 / 3) / (2 * math.pi) * math.log(mu / MZ))
        inv_t = inv + (11 - 10 / 3) / (2 * math.pi) * math.log(172.7 / MZ)
        return 1 / (inv_t + (11 - 4) / (2 * math.pi) * math.log(mu / 172.7))
    for hi, lo, nf in seg:
        b0 = 11 - 2 * nf / 3
        if mu >= lo:
            return 1 / (inv + b0 / (2 * math.pi) * math.log(mu / hi))
        inv = inv + b0 / (2 * math.pi) * math.log(lo / hi)
    return float("nan")
def alpha_G(mu):                                   # gravity's dimensionless coupling at energy μ
    return (mu / 1.220890e19)**2                    # (μ / M_Planck)²
grid_mu = np.logspace(-1, 19, 41)
print("\n    S[e-folds]  μ[GeV]      α_s      α_1      α_2      α_G")
for mu in grid_mu[::5]:
    a1 = 1 / (a1i - b_SM[0] / (2 * math.pi) * math.log(mu / MZ)) if mu > MZ else 1 / a1i
    a2 = 1 / (a2i - b_SM[1] / (2 * math.pi) * math.log(mu / MZ)) if mu > MZ else 1 / a2i
    as_ = alpha_s(mu); as_txt = f"{as_:7.4f}" if 0 < as_ < 1 else " >1 (confined)"
    print(f"    {S_of(R_of_mu(mu)):8.1f}  {mu:9.2e}  {as_txt}  {a1:7.4f}  {a2:7.4f}  {alpha_G(mu):8.1e}")
# where does the strong force become strong (α_s = 1)?
from scipy.optimize import brentq
mu_strong = brentq(lambda m: alpha_s(m) - 1.0, 0.25, 1.27)
R_strong = R_of_mu(mu_strong)
# where does gravity become as strong as electromagnetism? α_G(μ) = α  →  μ = √α M_P
mu_G_EM = math.sqrt(ALPHA0) * 1.220890e19
record("L6a", "DIAGNOSTIC", "Force layers along S (one-loop running)",
       f"α_s = 1 at μ = {mu_strong:.2f} GeV (S = {S_of(R_strong):.1f}); gravity = EM strength at μ = {mu_G_EM:.1e} GeV (S = {S_of(R_of_mu(mu_G_EM)):.1f})",
       note="Each force has its own S-range where it dominates: the paper's Material-Field layers.")

# ── tier boundaries predicted from the couplings ─────
a0 = 5.29177e-11
alphaG_p = G_SI * MP_KG**2 / (HBAR * C_SI)          # gravitational coupling of the proton
preds = []
def tier_test(tid, claim, pred, obs, unit, rule_dex=0.5, note=""):
    d = abs(math.log10(pred / obs))
    preds.append((tid, pred, obs))
    record(tid, "TEST", claim, f"predicted {pred:.2e} {unit} vs observed {obs:.2e} {unit} ({d:.2f} dex)",
           rule=f"within {rule_dex} dex", passed=bool(d < rule_dex), note=note)
p_rad = [rw for rw in rows if rw["name"] == "proton"][0]["R"]
tier_test("T9a", "Hadron tier: size where the strong coupling reaches 1", R_strong, p_rad, "m",
          note="One-loop running; the strong force 'closes' at this S and hadrons appear.")
rho_strong = MP_KG / (4 / 3 * math.pi * R_strong**3)
rho_nuc_obs = 10**np.mean(nuclear)
tier_test("T9b", "Nuclear density line from the strong scale", rho_strong, rho_nuc_obs, "kg/m³")
rho_EM = MP_KG / (4 / 3 * math.pi * a0**3)
rocky = [rw for rw in rows if rw["name"] in ("Moon", "Earth")]
rho_cond_obs = 10**np.mean([rw["log_rho"] for rw in rocky])
first_def = 10**np.mean(condensed)
tier_test("T9c", "Condensed-matter density line from the EM scale (a0 = ħ/m_e c α), vs rocky bodies", rho_EM, rho_cond_obs, "kg/m³",
          rule_dex=1.0, note=f"First run compared against all 'condensed' catalogue entries ({first_def:.0e} kg/m³) and failed (1.0 dex): "
                             "organism/cell 'radii' in the catalogue are lengths, not sphere radii, so their M/R³ is not a density. "
                             "Now compared only with bodies whose radius is a true radius (Moon, Earth).")
R_cold = math.sqrt(ALPHA0 / alphaG_p) * a0
R_jup = [rw for rw in rows if rw["name"] == "Jupiter"][0]["R"]
tier_test("T9d", "Gravity/EM crossover: largest cold body R ~ √(α/α_G)·a0", R_cold, R_jup, "m",
          note="Above this size gravity, not chemistry, sets a body's density: the planet→star boundary.")
M_star = alphaG_p**-1.5 * MP_KG
tier_test("T9e", "Star tier: M ~ α_G^(−3/2) m_p (Chandrasekhar-type scale)", M_star, MSUN, "kg")
# galaxy tier: GM-specific — the vacuum scale g† sets a characteristic surface density Σ† = g†/(2πG)
Sigma_GM = G_DAG(67.4) / (2 * math.pi * G_SI)       # kg/m²
MSUN_PC2 = MSUN / (3.0856775814913673e16)**2
print(f"\n    galaxy tier (GM-specific): Σ† = g†/(2πG) = {Sigma_GM/MSUN_PC2:.0f} M☉/pc²  (tested on SPARC in §5)")

# ── replicator window from the same boundaries ────────
win_lo, win_hi = 10 * a0, R_cold                     # need chemistry (≥ molecules) and no gravitational crushing
reps = [rw for rw in rows if rw["replicator"]]
inside = all(win_lo <= r_["R"] <= win_hi for r_ in reps)
record("T10a", "TEST", "Physical replicators lie inside the chemistry window [≈10 a0, √(α/α_G) a0]",
       f"window S = {S_of(win_lo):.1f}–{S_of(win_hi):.1f}; catalogued replicators S = "
       f"{min(r_['S'] for r_ in reps):.1f}–{max(r_['S'] for r_ in reps):.1f}",
       rule="all inside", passed=bool(inside),
       note="Upper end of real replicators (≈45 m) sits well below the window edge: other limits (material strength, "
            "metabolism) cut in first. GM does not yet predict those.")
CHAIN = {"vectors": VEC, "mu_strong_GeV": mu_strong, "mu_gravity_EM_GeV": mu_G_EM,
         "predictions": [{"id": a_, "pred": b_, "obs": c_} for a_, b_, c_ in preds],
         "Sigma_GM_Msun_pc2": Sigma_GM / MSUN_PC2}
(RES / "sections03_06_10_chain.json").write_text(json.dumps(CHAIN, indent=2, default=float))
