# ============================================================
# §5.2 — Groups and clusters of galaxies
#
# Model (no new constant except P0, which is measured once):
#   1. Cluster layer: the paper's field law on the baryons, g = ν(y) g_bar, y = g_bar/g†.
#   2. Sign flip: every member galaxy keeps its own Darkness (its isolated profile),
#      out to where it stops standing out from the surrounding MATTER (Selector):
#      ρ_D,gal(r) = √(M g†/G)/(4π r²) = ρ_matter(R).
#      Galaxy stellar mass function: Vulcani+12 (log M* = 11.15, α = −1.03);
#      stars spread with NFW c* = 7.1 (van der Burg+14); measured stellar fractions
#      (KVM18 for A85, A1795, A2029, A2142; Eckert+22 for A644, A2319; their median 1.35 %
#      of M500 elsewhere); BCG+envelope as a Hernquist profile, half-mass radius 100 kpc.
#   3. Hot plasma: ionised gas is de-structured matter; by the sign flip it feeds Darkness
#      instead of relaxing it. Thermal pressure keeps the vacuum unrelaxed:
#      y_eff = y / (1 + P_th/P0). Galaxies and cold groups (no hot gas) are unchanged.
#
# CL1 MEASUREMENT  P0 from the 12 X-COP clusters (pressure from hydrostatic equilibrium).
# CL2 MEASUREMENT  Frozen P0 on the 10 clusters with masses from galaxy kinematics (Li+23);
#           pressure from the Arnaud+10 universal profile. Residual per radial region.
# CL3 TEST  Frozen P0 on 15 relaxed X-ray groups (Gastaldello+07, Table 4), cores (r < 0.2 r_Δ).
#           Rule: |median| < 0.15 dex.
# CL4 DIAGNOSTIC  Central cluster galaxies (MaNGA BCGs, Tian+24): predicted vs observed
#           offset above the galaxy relation.
# ============================================================
print("── §5.2: groups and clusters ────────────────────────")
import collections
from scipy.optimize import minimize_scalar
G_ = 6.674e-11; MS_ = 1.989e30; KP_ = 3.0857e19; C_ = 299792458.0
gdag = G_DAG(67.4)
nuF = lambda y: 1.0 / (1.0 - np.exp(-np.sqrt(np.maximum(y, 1e-12))))
lawF = lambda g: g * nuF(g / gdag)
RHO_C = 3 * (67.4e3 / MPC_M)**2 / (8 * math.pi * G_)
KVM18 = {"A85": (1235, 5.98e14, 3.06e12, 5.28e12), "A1795": (1196, 5.46e14, 1.47e12, 4.01e12),
         "A2029": (1387, 8.64e14, 4.14e12, 8.21e12), "A2142": (1539, 11.96e14, 3.12e12, 12.22e12)}
ALIAS = {"A0085": "A85", "A1795": "A1795", "A2029": "A2029", "A2142": "A2142"}
FSTAR = {"A644": 0.013, "A2319": 0.015}; FSTAR_MED = 0.0135
LMS, ALPHA = 11.15, -1.03
_lm = np.linspace(8, 12.5, 100); _dl = _lm[1] - _lm[0]
_w = (10**_lm / 10**LMS)**(ALPHA + 1) * np.exp(-10**_lm / 10**LMS) * math.log(10) * _dl
_norm = np.sum(_w * 10**_lm)
fNFW = lambda x: np.log(1 + x) - x / (1 + x)

def darkness(M, rt):                       # a galaxy's Darkness inside rt (its own field law)
    gN = G_ * M / rt**2
    return max(gN * nuF(gN / gdag) * rt**2 / G_ - M, 0.0)
def reach(M, rho):                         # where its Darkness density = surrounding matter density
    return math.sqrt(math.sqrt(M * gdag / G_) / (4 * math.pi * rho))
def gal_darkness(Msat_r, Mbcg, rho, R):
    D = sum((Msat_r / MS_ / _norm) * wi * darkness(10**x * MS_, min(reach(10**x * MS_, rho), R))
            for x, wi in zip(_lm, _w))
    return D + darkness(Mbcg, min(reach(Mbcg, rho), R))
def members(nm, M5, R, R5):
    if nm in KVM18:
        _, _, Mb, Ms_ = KVM18[nm]; Mbcg, Msat = Mb * MS_, Ms_ * MS_
    else:
        Mbcg = 10**(12.15 + 0.39 * math.log10(M5 / MS_ / 1e14)) * MS_
        Msat = max(FSTAR.get(nm, FSTAR_MED) * M5 - Mbcg, 0.2 * FSTAR_MED * M5)
    rs = 1.5 * R5 / 7.1
    Msat_r = Msat * np.minimum(fNFW(R / rs) / fNFW(R5 / rs), 1.0)
    Mbcg_r = Mbcg * R**2 / (R + 100 * KP_ / (1 + math.sqrt(2)))**2
    return Mbcg, Msat_r, Mbcg_r
def regions(r, res, edges=((0, 200), (200, 500), (500, 1000), (1000, 1e9))):
    return {lo: float(np.median(res[(r >= lo) & (r < hi)])) for lo, hi in edges if ((r >= lo) & (r < hi)).any()}
def P_universal(r_kpc, M5):
    R5 = (M5 / (500 * RHO_C * 4 / 3 * math.pi))**(1 / 3) / KP_
    P500 = 1.65e-3 * (M5 / MS_ / (3e14 / 0.674 * 0.7))**(2 / 3) * (0.674 / 0.7)**2
    x = r_kpc / R5
    Pe = P500 * 8.403 * (0.7 / 0.674)**1.5 / ((1.177 * x)**0.3081 * (1 + (1.177 * x)**1.0510)**((5.4905 - 0.3081) / 1.0510))
    return 1.92 * Pe * 1.602e-10            # total thermal pressure, Pa

# ── X-COP: measure P0 ───────────────────────────────────────
XC = collections.defaultdict(list)
fx = DATA / "clusters" / "xcop_profiles.txt"
if fx.exists():
    for l in fx.read_text().splitlines():
        if l.strip() and not l.startswith("#"):
            p = l.split(); XC[p[0]].append([float(v) for v in p[1:]])
XPRE = []
for nm, a in XC.items():
    a = np.array(a)
    rin, rout, Rall = a[:, 0] * KP_, a[:, 1] * KP_, a[:, 2] * KP_
    Mg_all, Mt_all = a[:, 6] * MS_, (a[:, 3] + a[:, 6]) * MS_
    rg = np.diff(np.concatenate([[0], Mg_all])) / (4 / 3 * np.pi * (rout**3 - rin**3))
    Pth = np.cumsum((rg * G_ * Mt_all / Rall**2 * (rout - rin))[::-1])[::-1]
    s = (a[:, 2] >= 50) & (a[:, 2] <= 3000)
    r, R, Mgas, Mtot, P = a[s, 2], Rall[s], Mg_all[s], Mt_all[s], Pth[s]
    i5 = np.argmin(abs(Mtot / (4 / 3 * math.pi * R**3) - 500 * RHO_C)); R5, M5 = R[i5], Mtot[i5]
    Mbcg, Msat_r, Mbcg_r = members(nm, M5, R, R5)
    Mbar = Mgas + Msat_r + Mbcg_r; gb = G_ * Mbar / R**2
    rho = Mbar * np.clip(np.gradient(np.log(Mbar), np.log(R)), 0.05, 3) / (4 * math.pi * R**3)
    Dk = np.array([gal_darkness(Msat_r[i], Mbcg, rho[i], R[i]) for i in range(len(R))])
    XPRE.append((r, R, Mtot, gb, Dk, P))
def xcop_regions(P0):
    per = collections.defaultdict(list)
    for r, R, Mtot, gb, Dk, P in XPRE:
        y = gb / gdag / (1 + P / P0)
        res = np.log10(G_ * Mtot / R**2 / (gb * nuF(y) + G_ * Dk / R**2))
        for k, v in regions(r, res).items(): per[k].append(v)
    return {k: float(np.median(v)) for k, v in sorted(per.items())}
if XPRE:
    lP0 = minimize_scalar(lambda l: sum(v**2 for v in xcop_regions(10**l).values()), bounds=(-14, -8), method="bounded").x
    P0 = 10**lP0
    xr0, xr1 = xcop_regions(1e99), xcop_regions(P0)
    print(f"  X-COP ({len(XPRE)}): without plasma term " + " ".join(f"{v:+.2f}" for v in xr0.values()) +
          f" | with P0 = {P0:.2e} Pa: " + " ".join(f"{v:+.2f}" for v in xr1.values()))
    record("CL1", "MEASUREMENT", "Pressure scale P0 at which hot plasma keeps the vacuum unrelaxed (X-COP, 12 clusters)",
           f"P0 = {P0:.2e} Pa; regions (<200, 200–500, 500–1000, >1000 kpc): " + ", ".join(f"{v:+.2f}" for v in xr1.values()),
           note="Galaxies' Darkness alone: " + ", ".join(f"{v:+.2f}" for v in xr0.values()) + " dex.")

# ── Kinematic clusters: out-of-sample test ─────────────────
fk = DATA / "clusters" / "clusterRAR.dat"
if XPRE and fk.exists():
    KC = collections.defaultdict(list)
    for l in fk.read_text().splitlines():
        if l.strip() and not l.startswith("#"):
            p = l.split(); KC[p[0]].append((float(p[2]), 10**float(p[3]), 10**float(p[4])))
    allr, allres = [], []
    per_reg = collections.defaultdict(list)
    for nm, pts in KC.items():
        pts = sorted(pts); r = np.array([q[0] for q in pts]); R = r * KP_
        gb = np.array([q[1] for q in pts]); go = np.array([q[2] for q in pts])
        Mt = go * R**2 / G_; Mb_data = gb * R**2 / G_
        md = Mt / (4 / 3 * math.pi * R**3); lr, ld = np.log(R), np.log(md)
        if ld[-1] > math.log(500 * RHO_C):
            sl = (ld[-1] - ld[-2]) / (lr[-1] - lr[-2]) if len(R) > 1 else -2.0
            R5 = math.exp(lr[-1] + (math.log(500 * RHO_C) - ld[-1]) / sl)
        else:
            R5 = math.exp(np.interp(math.log(500 * RHO_C), ld[::-1], lr[::-1]))
        M5 = 500 * RHO_C * 4 / 3 * math.pi * R5**3
        key = ALIAS.get(nm, nm)
        if key in KVM18: R5 = KVM18[key][0] * KP_; M5 = KVM18[key][1] * MS_
        Mbcg, Msat_r, _ = members(key, M5, R, R5)
        Mmat = Mb_data + Msat_r      # data baryons already contain gas, BCG and member stars
        rho = Mmat * np.clip(np.gradient(np.log(Mmat), np.log(R)), 0.05, 3) / (4 * math.pi * R**3) if len(R) > 1 else Mmat / (4 / 3 * math.pi * R**3)
        P = P_universal(r, M5)
        res = []
        for i in range(len(R)):
            Dk = gal_darkness(Msat_r[i], Mbcg, rho[i], R[i])
            y = gb[i] / gdag / (1 + P[i] / P0)
            res.append(math.log10(go[i] / (gb[i] * nuF(y) + G_ * Dk / R[i]**2)))
        res = np.array(res)
        for k, v in regions(r, res).items(): per_reg[k].append(v)
    kreg = {k: float(np.median(v)) for k, v in sorted(per_reg.items())}
    print("  kinematic clusters (P0 frozen): " + " ".join(f"{v:+.2f}" for v in kreg.values()))
    record("CL2", "MEASUREMENT", "Frozen P0 on cluster masses from galaxy kinematics (Li+23, 10 clusters), residual per radial region",
           ", ".join(f"{k}+ kpc: {v:+.2f}" for k, v in kreg.items()),
           note="Independent of X-COP: different clusters (6 of 10) and a different mass method. In the 4 shared clusters the two "
                "methods differ by up to 0.2 dex at 200–500 kpc (A2029).")

# ── X-ray groups: out-of-sample test of the cores ───────────
GR = [("NGC5044",77,3.8,295,1.85,1.21,None,2.87,4.53),("NGC1550",48,4.5,215,1.42,1.02,0.53,2.09,3.05),("NGC2563",76,2.4,185,.92,.31,None,2.66,3.73),
      ("A262",141,2.1,292,3.59,2.60,0.54,4.12,10.16),("NGC533",43,6.1,262,1.30,.87,0.36,6.14,9.22),("MKW4",81,4.3,353,3.21,2.84,0.86,7.18,10.25),
      ("IC1860",101,3.2,319,2.36,1.56,0.60,4.38,8.03),("NGC5129",43,5.2,226,.84,.58,0.06,4.99,6.60),("NGC4325",75,2.8,208,1.32,.66,None,2.33,5.22),
      ("ESO552",171,2.5,422,5.51,3.35,None,8.19,15.7),("AWM4",154,3.0,465,7.38,4.79,0.30,7.50,10.33),("ESO306",162,2.1,343,5.97,3.45,None,6.95,18.51),
      ("RGH80",78,5.1,397,1.85,2.85,None,2.39,6.23),("MS0116",202,2.0,405,4.92,1.97,None,5.77,9.69),("A2717",233,3.0,710,10.68,11.36,None,5.42,15.53)]
#  (name, r_s kpc, c_Δ, r_Δ kpc, M_Δ 1e13, M_gas,Δ 1e12, stellar M/L_K or None, L_K 1e11, r_e kpc) — Gastaldello+07 Tables 2, 4, 6
if XPRE:
    core = collections.defaultdict(list)
    mb = lambda x: x - np.arctan(x)
    for nm, rs, c, rD, MD, Mg, ML, LK, re in GR:
        r = np.geomspace(0.05, 1.0, 40) * rD; R = r * KP_
        Mdm = (MD * 1e13 - Mg * 1e12) * fNFW(r / rs) / fNFW(rD / rs) * MS_
        rc_ = 0.1 * rD; Mgas = Mg * 1e12 * mb(r / rc_) / mb(rD / rc_) * MS_
        Mbcg = LK * 1e11 * (ML if ML else 0.6) * MS_; Mb = Mbcg * r**2 / (r + re / 1.8153)**2
        Mobs = Mdm + Mgas + Mb
        Msat = max(0.02 * MD * 1e13 * MS_ - Mbcg, 0.004 * MD * 1e13 * MS_)
        Msr = Msat * np.minimum(fNFW(r / (rD / 7.1)) / fNFW(7.1), 1)
        Mbar = Mgas + Mb + Msr; gb = G_ * Mbar / R**2
        rho = Mbar * np.clip(np.gradient(np.log(Mbar), np.log(R)), 0.05, 3) / (4 * math.pi * R**3)
        rr = np.geomspace(0.05, 3.0, 120) * rD * KP_
        mg = lambda q: Mg * 1e12 * MS_ * mb(q / (rc_ * KP_)) / mb(rD / rc_)
        Mo = np.interp(rr, R, Mobs, right=Mobs[-1]) * np.where(rr > R[-1], rr / R[-1], 1)**0.5
        rgas = np.gradient(mg(rr), rr) / (4 * math.pi * rr**2)
        Pr = np.array([np.trapezoid((rgas * G_ * Mo / rr**2)[i:], rr[i:]) for i in range(len(rr))])
        P = np.interp(R, rr, Pr)
        for i in range(len(R)):
            if r[i] / rD >= 0.2: continue
            Dk = gal_darkness(Msr[i], Mbcg, rho[i], R[i])
            for tag, P0x in (("base", 1e99), ("plasma", P0)):
                y = gb[i] / gdag / (1 + P[i] / P0x)
                core[(tag, nm)].append(math.log10(G_ * Mobs[i] / R[i]**2 / (gb[i] * nuF(y) + G_ * Dk / R[i]**2)))
    gb0 = float(np.median([np.median(v) for (t, n), v in core.items() if t == "base"]))
    gb1 = float(np.median([np.median(v) for (t, n), v in core.items() if t == "plasma"]))
    print(f"  X-ray group cores (P0 frozen): {gb0:+.2f} → {gb1:+.2f} dex")
    record("CL3", "TEST", "Frozen P0 fills the cores of 15 relaxed X-ray groups (Gastaldello+07)",
           f"core residual (r < 0.2 r_Δ): {gb0:+.2f} without the plasma term → {gb1:+.2f} with it",
           rule="|median| < 0.15 dex", passed=bool(abs(gb1) < 0.15),
           note="Group profiles rebuilt from the published NFW, gas and stellar fits (β-model gas, f* = 2 %).")

    # ── Central cluster galaxies (MaNGA BCGs, Tian+24) ──
    rows = []
    for lgb in (-10.4, -9.5, -8.9):
        gbv = 10**lgb; obs = 0.52 * lgb - 4.19; base = math.log10(lawF(gbv))
        pr = [math.log10(gbv * nuF(gbv / gdag / (1 + P_universal(rk, M5) / P0))) - base
              for M5 in (1e14 * MS_, 3e14 * MS_, 1e15 * MS_) for rk in (10, 20, 30)]
        rows.append((lgb, obs - base, float(np.median(pr))))
    record("CL4", "DIAGNOSTIC", "Central cluster galaxies sit above the galaxy relation by the amount hot gas predicts (MaNGA BCGs, Tian+24)",
           "; ".join(f"log g_bar {a}: observed {b:+.2f}, predicted {c:+.2f}" for a, b, c in rows))
