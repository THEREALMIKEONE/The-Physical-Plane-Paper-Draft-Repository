# ============================================================
# §6–§7 — Cosmology module: background, SN, BAO, CMB likelihoods
#
# Dark-energy models (flat universe):
#   lcdm : ρ_Λ = const                                      (reference)
#   rvm  : GM — Λ_eff ∝ μ² (I.11) with the cosmic slice tracking μ ~ H:
#          ρ_Λ(H) = ρ_Λ0 + 3ν M_p² (H² − H0²); total energy conserved,
#          so matter/radiation exchange with the vacuum: ρ_m ∝ (1+z)^{3(1−ν)}.
#          GM sign prediction: ν > 0 (vacuum energy grows with μ).
#   w0wa : CPL reference, so GM is compared against what the data prefer
#
# Data:
#   SN   Pantheon+ (Brout+22): m_b_corr + full STAT+SYS covariance,
#        z > 0.01, calibrators excluded, absolute magnitude marginalised.
#   BAO  DESI DR2 (2025) with full covariance (Cobaya bao_data release);
#        falls back to DESI DR1 (DESI 2024 VI, Table 1) if the files are missing.
#   CMB  Planck 2018 distance priors (Chen, Huang & Wang 2019, arXiv:1808.05724):
#        R, l_A, ω_b with correlation matrix.
# ============================================================
from scipy.optimize import minimize

OMEGA_G_H2 = 2.469e-5          # photons, T_CMB = 2.7255 K
NEFF = 3.044

def rho_de(z, p):
    m = p["model"]
    if m == "lcdm":
        return np.ones_like(z)
    if m == "gm":
        return (1 + z)**(3 * p["s"])
    if m == "w0wa":
        return (1 + z)**(3 * (1 + p["w0"] + p["wa"])) * np.exp(-3 * p["wa"] * z / (1 + z))
    raise ValueError(m)

def E(z, p):
    Or = OMEGA_G_H2 * (1 + 0.2271 * NEFF) / p["h"]**2
    if p["model"] == "rvm":
        nu = p["nu"]
        return np.sqrt((p["Om"] * (1 + z)**(3 * (1 - nu)) + Or * (1 + z)**(4 * (1 - nu))) / (1 - nu)
                       + 1 - (p["Om"] + Or) / (1 - nu))
    Ode = 1 - p["Om"] - Or
    return np.sqrt(p["Om"] * (1 + z)**3 + Or * (1 + z)**4 + Ode * rho_de(z, p))

def Om_of_a(a, p):
    """matter fraction Ω_m(a) used by the growth equation"""
    zz = np.array([1 / a - 1]); e2 = float(E(zz, p)[0])**2
    expo = 3 * (1 - p["nu"]) if p["model"] == "rvm" else 3
    return p["Om"] * a**(-expo) / e2

LNZ = np.linspace(0, math.log(1 + 1200.0), 24001)
ZG = np.expm1(LNZ)
def chi_grid(p):
    """dimensionless comoving distance  χ = ∫ dz/E  on ZG"""
    f = (1 + ZG) / E(ZG, p)
    return np.concatenate([[0], np.cumsum(0.5 * (f[1:] + f[:-1]) * np.diff(LNZ))])

# ── SN: Pantheon+ ───────────────────────────────────────────
def load_pantheon():
    lines = (DATA / "PantheonPlusSH0ES.dat").read_text().splitlines()
    hdr = lines[0].split()
    rows = [l.split() for l in lines[1:] if l.strip()]
    col = lambda n, f=float: np.array([f(r[hdr.index(n)]) for r in rows])
    zhd, zhel, mb = col("zHD"), col("zHEL"), col("m_b_corr")
    calib = col("IS_CALIBRATOR", lambda v: int(float(v)))
    raw = np.loadtxt(DATA / "PantheonPlusSH0ES_STAT+SYS.cov")
    n = int(raw[0]); C = raw[1:].reshape(n, n)
    m = (zhd > 0.01) & (calib == 0)
    Cm = C[np.ix_(m, m)]
    W = np.linalg.inv(Cm)
    return {"zhd": zhd[m], "zhel": zhel[m], "mb": mb[m], "W": W,
            "W1": W.sum(axis=1), "S1": W.sum(), "n": int(m.sum())}

def chi2_sn(p, chi, SN):
    mu = 5 * np.log10((1 + SN["zhel"]) * np.interp(SN["zhd"], ZG, chi))
    d = SN["mb"] - mu
    Wd = SN["W"] @ d
    return float(d @ Wd - (SN["W1"] @ d)**2 / SN["S1"])   # offset (M, H0) marginalised

# ── BAO: DESI DR1 ───────────────────────────────────────────
DESI = [  # (z, kind, value, err)   kinds: V = D_V/r_d, MH = (D_M/r_d, D_H/r_d, r)
    (0.295, "V", 7.93, 0.15),
    (0.510, "MH", (13.62, 20.98), (0.25, 0.61), -0.445),
    (0.706, "MH", (16.85, 20.08), (0.32, 0.60), -0.420),
    (0.930, "MH", (21.71, 17.88), (0.28, 0.35), -0.389),
    (1.317, "MH", (27.79, 13.82), (0.69, 0.42), -0.444),
    (1.491, "V", 26.07, 0.67),
    (2.330, "MH", (39.71, 8.52), (0.94, 0.17), -0.477),
]
def z_drag(wb, wm):  # Eisenstein & Hu 1998
    b1 = 0.313 * wm**-0.419 * (1 + 0.607 * wm**0.674)
    b2 = 0.238 * wm**0.223
    return 1291 * wm**0.251 / (1 + 0.659 * wm**0.828) * (1 + b1 * wb**b2)

def rd_fit(p):
    """sound horizon at drag (Mpc), computed numerically for ANY model
    (the RVM changes pre-recombination expansion), calibrated to Planck ΛCDM (147.09 Mpc)"""
    return CAL_RD * rs_star(p, z_drag(p["wb"], p["Om"] * p["h"]**2))

def load_bao_dr2():
    fm, fc = DATA / "DESI_DR2_BAO_mean.txt", DATA / "DESI_DR2_BAO_cov.txt"
    if not (fm.exists() and fc.exists()):
        return None
    rows = [l.split() for l in fm.read_text().splitlines() if l.strip() and not l.startswith("#")]
    z = np.array([float(r[0]) for r in rows]); val = np.array([float(r[1]) for r in rows])
    kind = [r[2] for r in rows]
    W = np.linalg.inv(np.loadtxt(fc))
    return {"z": z, "val": val, "kind": kind, "W": W}
BAO2 = load_bao_dr2()

def chi2_bao(p, chi):
    q = C_KMS / (100 * p["h"] * rd_fit(p)) if "hrd" not in p else C_KMS / (100 * p["hrd"])
    if BAO2 is not None:
        th = []
        for zb, kd in zip(BAO2["z"], BAO2["kind"]):
            DM = q * np.interp(zb, ZG, chi); DH = q / float(E(np.array([zb]), p)[0])
            th.append({"DM_over_rs": DM, "DH_over_rs": DH,
                       "DV_over_rs": (zb * DM**2 * DH)**(1 / 3)}[kd])
        d = np.array(th) - BAO2["val"]
        return float(d @ BAO2["W"] @ d)
    out = 0.0
    for row in DESI:
        zb = row[0]
        DM = q * np.interp(zb, ZG, chi)
        DH = q / float(E(np.array([zb]), p)[0])
        if row[1] == "V":
            DV = (zb * DM**2 * DH)**(1 / 3)
            out += ((DV - row[2]) / row[3])**2
        else:
            (vm, vh), (em, eh), r = row[2], row[3], row[4]
            Cb = np.array([[em**2, r * em * eh], [r * em * eh, eh**2]])
            dv = np.array([DM - vm, DH - vh])
            out += float(dv @ np.linalg.solve(Cb, dv))
    return out

# ── CMB: Planck 2018 distance priors ────────────────────────
CMB_MEAN = np.array([1.7502, 301.471, 0.02236])
CMB_SIG = np.array([0.0046, 0.0895, 0.00015])
CMB_CORR = np.array([[1.0, 0.46, -0.66], [0.46, 1.0, -0.33], [-0.66, -0.33, 1.0]])
CMB_W = np.linalg.inv(CMB_CORR * np.outer(CMB_SIG, CMB_SIG))

def z_star(wb, wm):  # Hu & Sugiyama 1996
    g1 = 0.0783 * wb**-0.238 / (1 + 39.5 * wb**0.763)
    g2 = 0.560 / (1 + 21.1 * wb**1.81)
    return 1048 * (1 + 0.00124 * wb**-0.738) * (1 + g1 * wm**g2)

def rs_star(p, zs):
    lz = np.linspace(math.log(1 + zs), math.log(1 + 1e7), 6000)
    zz = np.expm1(lz)
    Rb = 3 * p["wb"] / (4 * OMEGA_G_H2) / (1 + zz)
    f = (1 + zz) / (E(zz, p) * np.sqrt(3 * (1 + Rb)))
    return C_KMS / (100 * p["h"]) * float(np.sum(0.5 * (f[1:] + f[:-1]) * np.diff(lz)))

def cmb_raw(p, chi):
    wm = p["Om"] * p["h"]**2
    zs = z_star(p["wb"], wm)
    chis = float(np.interp(zs, ZG, chi))
    R = math.sqrt(p["Om"]) * chis
    lA = math.pi * C_KMS / (100 * p["h"]) * chis / rs_star(p, zs)
    return R, lA

# Calibrate the semi-analytic z*, r_s against the Planck ΛCDM best fit.
# (Approximation offsets are early-universe physics, identical for all models here.)
P_PLANCK = {"model": "lcdm", "h": 0.6736, "Om": 0.3153, "wb": 0.02237}
CAL_RD = 1.0
CAL_RD = 147.09 / rd_fit(P_PLANCK)
_R0, _lA0 = cmb_raw(P_PLANCK, chi_grid(P_PLANCK))
CAL_R, CAL_LA = 1.7502 / _R0, 301.471 / _lA0
print(f"  calibration vs Planck ΛCDM: R ×{CAL_R:.5f}, l_A ×{CAL_LA:.5f}, r_d ×{CAL_RD:.5f}")

def chi2_cmb(p, chi):
    R, lA = cmb_raw(p, chi)
    d = np.array([R * CAL_R, lA * CAL_LA, p["wb"]]) - CMB_MEAN
    return float(d @ CMB_W @ d)

SN = load_pantheon()
print(f"  Pantheon+ SNe used: {SN['n']}   BAO: " + (f"DESI DR2, {len(BAO2['z'])} points, full covariance" if BAO2 is not None
      else f"DESI DR1 fallback, {sum(1 if r[1]=='V' else 2 for r in DESI)} points"))

# ── Generic fitter ──────────────────────────────────────────
def total_chi2(p, sets):
    if not (0.05 < p["Om"] < 0.7) or abs(p.get("nu", 0)) > 0.5:
        return 1e10
    chi = chi_grid(p)
    c = 0.0
    if "SN" in sets:  c += chi2_sn(p, chi, SN)
    if "BAO" in sets: c += chi2_bao(p, chi)
    if "CMB" in sets: c += chi2_cmb(p, chi)
    return c

def make_p(model, names, x, fixed):
    p = {"model": model, "h": 0.68, "wb": 0.02236}
    p.update(fixed); p.update(dict(zip(names, x)))
    return p

def fit_cosmo(model, sets, fixed=None, starts=None):
    fixed = dict(fixed or {})
    names = ["Om"]
    if "CMB" in sets:
        names += ["h", "wb"]
    elif "BAO" in sets:
        names += ["hrd"]
    names += {"lcdm": [], "rvm": ["nu"], "w0wa": ["w0", "wa"]}[model]
    names = [n for n in names if n not in fixed]
    x0s = starts or [None]
    best = None
    for x0 in x0s:
        init = {"Om": 0.31, "h": 0.68, "wb": 0.02236, "hrd": 0.68 * 147.0,
                "nu": 0.0, "w0": -0.9, "wa": -0.3}
        if x0: init.update(x0)
        r = minimize(lambda x: total_chi2(make_p(model, names, x, fixed), sets),
                     [init[n] for n in names], method="Nelder-Mead",
                     options={"xatol": 1e-6, "fatol": 1e-4, "maxiter": 6000, "maxfev": 6000})
        if best is None or r.fun < best.fun:
            best = r
    return {"chi2": float(best.fun), "params": dict(zip(names, map(float, best.x))),
            "k": len(names), **{k: v for k, v in fixed.items()}}


# ============================================================
# §6–§7 — Dark energy as the cosmic slice of Λ_eff(S): running vacuum
#
# Pre-registered rules:
#   C1  GM running vacuum not disfavoured vs ΛCDM:   ΔAIC(rvm − lcdm) < 4  (SN+BAO+CMB)
#   C2  GM sign prediction ν > 0 survives: the 2σ interval reaches ν ≥ 0
#   C3  CONSTRAINT on ν (size not predicted yet — GM must derive it)
#   D5  DIAGNOSTIC: what the data prefer (CPL w0, wa)
# ============================================================
print("── §6–7: running-vacuum dark energy ─────────────")
COSMO = {}
for sets in (("SN", "BAO"), ("SN", "BAO", "CMB")):
    key = "+".join(sets); COSMO[key] = {}
    for model in ("lcdm", "rvm", "w0wa"):
        f = fit_cosmo(model, sets, starts=[None, {"nu": 0.002, "w0": -0.7, "wa": -1.0},
                                           {"Om": 0.29, "nu": -0.002, "w0": -1.1, "wa": 0.2}])
        f["AIC"] = f["chi2"] + 2 * f["k"]; COSMO[key][model] = f
    l = COSMO[key]["lcdm"]
    print(f"\n  [{key}] ΛCDM χ² = {l['chi2']:.2f}  " + " ".join(f"{k}={v:.4f}" for k, v in l["params"].items()))
    for model in ("rvm", "w0wa"):
        f = COSMO[key][model]
        print(f"    {model:5s} Δχ² = {f['chi2']-l['chi2']:+7.2f}  ΔAIC = {f['AIC']-l['AIC']:+6.2f}  " +
              " ".join(f"{k}={v:.5f}" for k, v in f["params"].items()))

FULL = ("SN", "BAO", "CMB")
bf = COSMO["SN+BAO+CMB"]["rvm"]["params"]
def profile_nu(lo, hi, step):
    grid = np.round(np.arange(lo, hi + step / 2, step), 6); out = []
    for nv in grid:
        f = fit_cosmo("rvm", FULL, fixed={"nu": float(nv)}, starts=[{k: v for k, v in bf.items() if k != "nu"}])
        out.append(f["chi2"])
    return grid, np.array(out)
lo, hi, step = -0.003, 0.003, 0.00025
for _ in range(4):
    g_nu, p_nu = profile_nu(lo, hi, step)
    d = p_nu - p_nu.min()
    if d[0] > 6 and d[-1] > 6:
        break
    lo, hi, step = 2 * lo, 2 * hi, 2 * step
fine = np.linspace(g_nu[0], g_nu[-1], 4001); pf = np.interp(fine, g_nu, p_nu); pf -= pf.min()
nu_hat = float(fine[np.argmin(pf)])
nu1 = (float(fine[pf <= 1].min()), float(fine[pf <= 1].max()))
nu2 = (float(fine[pf <= 4].min()), float(fine[pf <= 4].max()))
print(f"\n  profile: ν = {nu_hat:+.5f}, 1σ [{nu1[0]:+.5f}, {nu1[1]:+.5f}], 2σ [{nu2[0]:+.5f}, {nu2[1]:+.5f}]")

g = COSMO["SN+BAO+CMB"]
dAIC = g["rvm"]["AIC"] - g["lcdm"]["AIC"]
record("C1", "TEST", "GM running vacuum (Λ_eff ∝ μ², μ ~ H) not disfavoured vs ΛCDM (SN+BAO+CMB)",
       f"ΔAIC = {dAIC:+.2f}, ν = {g['rvm']['params']['nu']:+.5f}", rule="ΔAIC < 4", passed=bool(dAIC < 4))
record("C2", "TEST", "GM sign prediction ν > 0 (vacuum energy grows with μ)",
       f"ν = {nu_hat:+.5f}; 2σ [{nu2[0]:+.5f}, {nu2[1]:+.5f}]", rule="2σ interval reaches ν ≥ 0",
       passed=bool(nu2[1] >= 0),
       note=f"ν/σ ≈ {nu_hat / ((nu1[1] - nu1[0]) / 2):.1f}σ above zero"
            + (" — the sign GM predicts, at ~2σ: a hint, not a detection (5σ)." if nu2[0] > 0 else " — consistent with zero."))
record("C3", "CONSTRAINT", "Size of the running (GM does not yet predict it)", f"|ν| ≲ {max(abs(nu2[0]), abs(nu2[1])):.4f} (2σ)")
w = g["w0wa"]
record("D5", "DIAGNOSTIC", "What the data prefer (CPL reference)",
       f"w0 = {w['params']['w0']:+.3f}, wa = {w['params']['wa']:+.3f}, ΔAIC = {w['AIC']-g['lcdm']['AIC']:+.2f}")
COSMO["profile_nu"] = {"nu": g_nu.tolist(), "chi2": p_nu.tolist(), "nu_hat": nu_hat, "1sigma": nu1, "2sigma": nu2}
(RES / "section11_2_cosmology.json").write_text(json.dumps(COSMO, indent=2, default=float))


# ============================================================
# §7 — Nucleosynthesis check on the running vacuum
#
# CC1 Early-universe consistency: at high H the running vacuum is a fraction ≈ ν
#     of the total energy. At nucleosynthesis (g* = 10.75) that acts like extra
#     radiation ΔN_eff ≈ ν·g*/(7/4). Rule: ΔN_eff < 0.3 (Planck/BBN level).
# ============================================================
print("── §7: nucleosynthesis check ──────────────────")
nu_hi = max(abs(v) for v in COSMO["profile_nu"]["2sigma"])
dN_bbn = nu_hi * 10.75 / 1.75
record("CC1", "TEST", "Running vacuum at nucleosynthesis behaves like at most a tiny extra radiation",
       f"ΔN_eff ≈ {dN_bbn:.3f} for |ν| ≤ {nu_hi:.4f}", rule="ΔN_eff < 0.3", passed=bool(dN_bbn < 0.3))
pr_ = COSMO["SN+BAO+CMB"]["rvm"]["params"]
rhoL = (1 - pr_["Om"]) * 3 * (100 * pr_["h"] * 1e3 / MPC_M * 6.582119569e-16)**2 * 2.435e27**2   # eV⁴


# ============================================================
# §4 — The vacuum-energy curve along S (the CC claim as stated)
#
# Claim: vacuum energy is a function of S. It is strong at small S, where the QFT values belong,
# and weak at cosmic S, where the observed Λ belongs. Both are real values at different places
# on the axis; summing or comparing them as one number is the category error.
#
# Points (magnitudes; standard estimates, not GM inputs):
#   cosmic       ρ_Λ (this notebook's SN+BAO+CMB ΛCDM fit)           at μ = H0
#   QCD          |ε_vac| = (9/32)⟨(α_s/π)G²⟩, condensate 0.012 GeV⁴ (SVZ 1979)   at μ = |ε|^¼
#   electroweak  |V_min| = m_H² v²/8 (m_H = 125.1, v = 246.2 GeV)      at μ = v
#   Planck       M_p⁴ (reduced Planck mass)                            at μ = M_p
#
# VS1 DIAG     the points and the local slopes d ln ρ / d ln μ between neighbours
# VS2 TEST     Law of the Dark, as stated (rule fixed before running): ρ_vac falls monotonically
#              from small S to large S AND the slope is steeper at small S than at large S.
# VS3 TEST     the geometry's own curve, ρ = M_p²μ² (I.11), passes every point within 1 dex.
# ============================================================
print("── §4: vacuum energy along S ────────────────────────")
GEV = 1e9
pts = []
pts.append(("cosmic (Λ)", 100 * pr_["h"] * 1e3 / MPC_M * 6.582119569e-16, rhoL))
eps_qcd = 9 / 32 * 0.012 * GEV**4
pts.append(("QCD (gluon condensate)", eps_qcd**0.25, eps_qcd))
mH, vEW = 125.1 * GEV, 246.2 * GEV
pts.append(("electroweak (Higgs potential)", vEW, mH**2 * vEW**2 / 8))
Mp_eV = 2.435e18 * GEV
pts.append(("Planck", Mp_eV, Mp_eV**4))
pts.sort(key=lambda t_: t_[1])                                 # increasing μ = decreasing S
print("    layer                          μ [eV]      ρ_vac [eV⁴]   M_p²μ² [eV⁴]   S from floor")
for nm, mu, rho in pts:
    Sfl = math.log(Mp_eV / mu)                                 # e-folds below the Planck floor (S = ln(μ_P/μ))
    print(f"    {nm:30s} {mu:9.2e}   {rho:10.2e}   {Mp_eV**2*mu**2:10.2e}   {Sfl:6.1f}")
slopes = [(pts[i][0], pts[i + 1][0], math.log(pts[i + 1][2] / pts[i][2]) / math.log(pts[i + 1][1] / pts[i][1])) for i in range(len(pts) - 1)]
record("VS1", "DIAGNOSTIC", "Vacuum energy at four places on the S axis, and the local slope between them",
       "; ".join(f"{a} → {b}: d lnρ/d lnμ = {sl:.2f}" for a, b, sl in slopes),
       note="QCD and electroweak values are standard estimates of the vacuum-energy scale (condensate, Higgs potential depth); "
            "their signs are negative in the Standard Model, magnitudes used here.")
mono = all(pts[i + 1][2] > pts[i][2] for i in range(len(pts) - 1))
steeper_small_S = all(slopes[i + 1][2] >= slopes[i][2] for i in range(len(slopes) - 1))
record("VS2", "TEST", "Law of the Dark along S: vacuum energy falls toward large S, steeply at small S and flatter at large S",
       f"monotonic: {mono}; slopes from cosmic upward: " + ", ".join(f"{sl:.2f}" for _, _, sl in slopes),
       rule="monotonic AND slope non-decreasing toward small S", passed=bool(mono and steeper_small_S),
       note="Consistent with the claim's shape. Not discriminating: the flat large-S end is the small observed Λ itself, "
            "so this shows the CC claim describes the data, not why the curve has this shape. Caution: the QCD and EW points are placed at μ ≈ ρ^¼, so slopes near 4 above QCD are partly built in; the informative segment is cosmic → QCD (slope ≈ 1).")
offs = [(nm, math.log10(rho / (Mp_eV**2 * mu**2))) for nm, mu, rho in pts]
ok_VS3 = all(abs(o) < 1 for _, o in offs)
record("VS3", "SUPERSEDED", "Single vacuum curve: the geometry's ρ = M_p²μ² (I.11) passes every point within 1 dex",
       "; ".join(f"{nm}: {o:+.1f} dex" for nm, o in offs), rule="every point within 1 dex", passed=bool(ok_VS3),
       note="Superseded formulation, kept with its pre-set rule and outcome. It compared the QCD and electroweak condensates "
            "with the geometric curve. In the framework the gravitating vacuum on a slice is the geometric part (I.11): it matches "
            "at the Planck floor (by normalisation) and at the cosmic slice (once μ = H0 is identified). The condensates are the "
            "Darkness of their layer's structures and are compared with those structures (SG1), not with M_p²μ².")
VAC = {"points": [{"layer": n, "mu_eV": m, "rho_eV4": r} for n, m, r in pts], "slopes": slopes, "offsets_vs_Mp2mu2_dex": offs}
(RES / "section07e_vacuum_along_S.json").write_text(json.dumps(VAC, indent=2, default=float))


# ============================================================
# §4 — The sign flip on the map
#
# Definitions: Darkness = the vacuum medium at a layer, "a substrate of structures existing
# inside the lower S"; virtual particles are fluctuations of Darkness; at the ceiling "our physics
# becomes the Darkness of a larger-scale system".
# Consequence: a layer's vacuum energy density is set by the structures of the layer just below it,
# so the two should be of the same order.
# SG1 TEST  Rule (stated before running): at each layer with data, |log10(ρ_vac / ρ_structures below)| < 1.
#           QCD layer: vacuum energy vs nuclear-matter density. Cosmic layer: ρ_Λ vs mean matter density (galaxies, ...).
# SG2 DIAG  Time dependence of the cosmic ratio.
# ============================================================
print("── §4: the sign flip on the map ───")
EV4_TO_KGM3 = 1.602176634e-19 / (1.97327e-7)**3 / C_SI**2
rq = eps_qcd * EV4_TO_KGM3; rn = 10**np.mean(nuclear)
pl2 = COSMO["SN+BAO+CMB"]["lcdm"]["params"]; Om2 = pl2["Om"]
ratios = {"QCD layer (vacuum vs nuclear matter)": rq / rn, "cosmic layer (ρ_Λ vs matter)": (1 - Om2) / Om2}
for k_, v_ in ratios.items(): print(f"    {k_}: ratio = {v_:.2f} ({math.log10(v_):+.2f} dex)")
record("SG1", "TEST", "Sign flip: a layer's vacuum energy matches the structures just below it",
       "; ".join(f"{k_}: {math.log10(v_):+.2f} dex" for k_, v_ in ratios.items()), rule="each within 1 dex",
       passed=bool(all(abs(math.log10(v_)) < 1 for v_ in ratios.values())),
       note="Passes. The QCD match is close to automatic, since both scale as (QCD scale)⁴. The cosmic match is the known "
            "'coincidence' that dark energy and matter are of the same order today.")
zr_ = [0, 1, 3, 9]
record("SG2", "DIAGNOSTIC", "Cosmic ratio over time", ", ".join(f"z={z_}: {(1-Om2)/(Om2*(1+z_)**3):.3g}" for z_ in zr_),
       note="The match holds only near today: at z = 9 the ratio is 10⁻³. Either the cosmic Darkness tracks its structures in a way "
            "not yet formulated, or this is the 'why now' problem again.")
