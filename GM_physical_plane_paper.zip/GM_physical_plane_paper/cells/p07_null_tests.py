# ============================================================
# §7 — Structure growth (BOSS fσ8) and lensing (KiDS S8) under the running vacuum
#
# Solves the linear growth equation in each fitted background:
#     D'' + (2 + dlnE/dlna) D' − 1.5 Ω_m(a) D = 0      (' = d/dlna)
# Amplitude: same primordial amplitude and early growth as Planck ΛCDM
# (σ8 = 0.8111, Planck 2018), only late-time growth differs.
# Neglects transfer-function shifts and vacuum–matter exchange in the
# perturbations (ν ~ 1e-3) → lensing labelled DIAGNOSTIC.
#
# Data:
#   BOSS DR12 final consensus fσ8 (Alam+17) with its full covariance (Cobaya bao_data);
#   falls back to the published diagonal errors if the files are missing
#   KiDS-1000 COSEBIs S8 (Asgari+21): 0.759 +0.024 −0.021
# ============================================================
from scipy.integrate import solve_ivp

BOSS = [(0.38, 0.497, 0.045), (0.51, 0.458, 0.038), (0.61, 0.436, 0.034)]
BOSS_W = np.diag([1 / e**2 for _, _, e in BOSS])
_fm, _fc = DATA / "BOSS_DR12_consensus_final.dat", DATA / "BOSS_DR12_consensus_cov.txt"
if _fm.exists() and _fc.exists():
    _rows = [l.split() for l in _fm.read_text().splitlines() if l.strip() and not l.startswith("#")]
    _idx = [i for i, r in enumerate(_rows) if r[2] == "f_sigma8"]
    _cov = np.loadtxt(_fc)[np.ix_(_idx, _idx)]
    BOSS = [(float(_rows[i][0]), float(_rows[i][1]), math.sqrt(_cov[j, j])) for j, i in enumerate(_idx)]
    BOSS_W = np.linalg.inv(_cov)
    print("  BOSS fσ8: full covariance, corr(0.38,0.51) = %.2f" % (_cov[0, 1] / math.sqrt(_cov[0, 0] * _cov[1, 1])))
KIDS_S8, KIDS_ERR = 0.759, 0.0225
SIG8_PLANCK = 0.8111

def growth(p, a_ini=1 / 31.0):
    def rhs(N, y):
        a = math.exp(N); zz = np.array([1 / a - 1])
        e = float(E(zz, p)[0])
        dz = 1e-4 * (1 + zz)
        dlnE = -(math.log(float(E(zz + dz, p)[0])) - math.log(float(E(zz - dz, p)[0]))) / (2 * dz[0]) * (1 + zz[0])
        Om_a = Om_of_a(a, p)
        return [y[1], -(2 + dlnE) * y[1] + 1.5 * Om_a * y[0]]
    sol = solve_ivp(rhs, [math.log(a_ini), 0.0], [a_ini, a_ini], dense_output=True,
                    rtol=1e-8, atol=1e-11)
    return sol

def fs8_S8(p):
    ref = growth(P_PLANCK)
    sol = growth(p)
    D0_ref = ref.sol(0.0)[0]
    out = {}
    for zb, _, _ in BOSS:
        D, dD = sol.sol(math.log(1 / (1 + zb)))
        out[zb] = SIG8_PLANCK * dD / D0_ref          # fσ8 = f·σ8(z) = σ8,ref · dD/dlna / D_ref(0)
    s8 = SIG8_PLANCK * sol.sol(0.0)[0] / D0_ref
    return out, s8 * math.sqrt(p["Om"] / 0.3), s8

print("── §7: growth and lensing ──────────────────────")
full = COSMO["SN+BAO+CMB"]
cases = {
    "ΛCDM (best fit)": make_p("lcdm", list(full["lcdm"]["params"]), list(full["lcdm"]["params"].values()), {}),
    "GM (best fit)":   make_p("rvm", list(full["rvm"]["params"]), list(full["rvm"]["params"].values()), {}),
}
GROWTH = {}
for name, p in cases.items():
    fs, S8, s8 = fs8_S8(p)
    dfs = np.array([fs[zb] - v for zb, v, e in BOSS])
    c_fs = float(dfs @ BOSS_W @ dfs)
    t_s8 = (S8 - KIDS_S8) / KIDS_ERR
    GROWTH[name] = {"fs8": fs, "S8": S8, "sigma8": s8, "chi2_boss": c_fs, "kids_sigma": t_s8}
    print(f"  {name:16s} σ8={s8:.4f} S8={S8:.4f} ({t_s8:+.2f}σ vs KiDS)  "
          f"fσ8: " + " ".join(f"{fs[zb]:.3f}" for zb, _, _ in BOSS) + f"  χ²_BOSS={c_fs:.2f}")

gm, lc = GROWTH["GM (best fit)"], GROWTH["ΛCDM (best fit)"]
record("C4", "TEST", "GM growth fits BOSS fσ8 no worse than ΛCDM",
       f"χ² GM {gm['chi2_boss']:.2f} vs ΛCDM {lc['chi2_boss']:.2f} (3 pts)",
       rule="χ²_GM − χ²_ΛCDM < 4", passed=bool(gm["chi2_boss"] - lc["chi2_boss"] < 4))
record("C5", "DIAGNOSTIC", "S8 tension with KiDS-1000 (no calibration to KiDS)",
       f"GM {gm['kids_sigma']:+.2f}σ, ΛCDM {lc['kids_sigma']:+.2f}σ",
       note="Not calibrated to KiDS. Here GM "
            + ("reduces" if abs(gm["kids_sigma"]) < abs(lc["kids_sigma"]) - 0.5 else "does not materially change")
            + " the S8 tension relative to ΛCDM.")
(RES / "section11_3_growth.json").write_text(json.dumps(GROWTH, indent=2, default=float))


# ============================================================
# §7 — Literal-5D limits and consistency (plus the g†(z) prediction table)
#
# B   g† = cH0/2π is a COSMIC scale ⇒ g†(z) = cH(z)/2π  (MOND: a0 constant)
#     → prediction table; data test needs high-z rotation curves with
#       baryonic accelerations (KMOS3D / Genzel+17, Nestor Shachar+23). NOT RUN here.
# D   If the 5th dimension is literal (AdS bulk, I.3): short-distance gravity
#     and the slice tension σ (I.12) are bounded by torsion balances.
# K   Consistency: GW speed, clocks (conditional on coupling to the cosmic slice)
# ============================================================
print("── §7: limits and consistency ────────")
pr = COSMO["SN+BAO+CMB"]["rvm"]["params"]; pG = make_p("rvm", list(pr), list(pr.values()), {})
zs_ = np.array([0.0, 0.5, 1.0, 1.5, 2.0, 2.5])
Ez = E(zs_, pG)
gz = G_DAG(100 * pG["h"]) * Ez
print("  z     H(z)/H0   g†_GM(z) [m/s²]   MOND a0")
for zz_, e_, g_ in zip(zs_, Ez, gz):
    print(f"  {zz_:3.1f}   {e_:6.3f}    {g_:.3e}        1.2e-10")
record("P1", "PROPOSED", "g†(z) = cH(z)/2π: the galactic scale grows with redshift (MOND: constant)",
       ", ".join(f"z={zz_:.0f}: {g_:.2e}" for zz_, g_ in zip(zs_, gz) if zz_ in (0.0, 1.0, 2.0)) + " m/s²",
       note="The expansion reading of 'set by the cosmic vacuum'. Tested on four high-redshift samples in Z1–Z5.")

# D — literal bulk: torsion-balance limit on gravitational-strength deviations λ < 38.6 μm (Lee+20, 95%)
ell_um = 38.6
k_eV = 0.19733 / ell_um              # ħc/ℓ  (0.19733 eV·μm)
Mp_eV_ = 2.435e27
sigma_quarter_TeV = (6 * k_eV**2 * Mp_eV_**2)**0.25 / 1e12     # RS tuning σ = 6 k² M_p²  (I.12 with κ⁴σ² = −6Λ5)
record("D1", "CONSTRAINT", "If the 5th dimension is literal: AdS radius and slice tension",
       f"ℓ ≲ {ell_um} μm  ⇒  σ^(1/4) ≳ {sigma_quarter_TeV:.1f} TeV",
       note="Approximate: maps the Yukawa-range limit onto the RS 1/r³ correction. The ρ² term of I.12 is then "
            "negligible after nucleosynthesis. The holographic reading has no such bound.")

# K1 — GW speed from I.14; GW170817 + GRB 170817A (Abbott+17, ApJL 848, L13): −3×10⁻¹⁵ ≤ Δc/c ≤ +7×10⁻¹⁶
dc_pred = 0.0 if GW_LUMINAL else float("nan")
record("Q1", "TEST", "Gravitational waves travel at c",
       f"predicted Δc/c = {dc_pred:g} (I.14); GW170817 allows −3e−15 to +7e−16",
       rule="prediction inside the GW170817 bound", passed=bool(-3e-15 <= dc_pred <= 7e-16))

# K2 — clocks, ONLY if atomic couplings depended on the cosmic slice S_cos = (1/k) ln(H/μ0):
#   dS_cos/dt = −(1+q)H/k  ⇒  α̇/α = β_EM (1+q0) H0
Om0 = pG["Om"]; q0 = 0.5 * Om0 - (1 - Om0)          # ΛCDM-like deceleration today
H0_yr_ = 100 * pG["h"] * 1e3 / MPC_M * YR_S
adot_max_ = 1.8e-19 + 2 * 2.5e-19                     # Filzinger+23, 2σ
bEM = adot_max_ / ((1 + q0) * H0_yr_)
record("Q2", "CONSTRAINT", "Clocks — only if atomic couplings tracked the cosmic slice",
       f"β_EM < {bEM:.1e}",
       note="In the layer reading (forces fixed by their own S), atomic couplings do not drift and this does not apply.")
# K2b — layer reading: atomic couplings sit at the atomic S, so they do not drift. Filzinger+23 (PRL 130, 253001): (1.8 ± 2.5)×10⁻¹⁹ /yr
adot_meas, adot_err = 1.8e-19, 2.5e-19
record("Q3", "TEST", "Clocks: no drift of the fine-structure constant (layer reading)",
       f"predicted 0; measured ({adot_meas*1e19:.1f} ± {adot_err*1e19:.1f})×10⁻¹⁹ /yr ({abs(adot_meas)/adot_err:.1f}σ)",
       rule="|measured − 0| < 2σ", passed=bool(abs(adot_meas) / adot_err < 2))

# K3 — H0 consequence of the running vacuum


# ============================================================
# §7 — S-floor and black holes
#
# FL1 TEST   S-floor = maximum density (Planck, I.13). Rule: every measured density in nature is
#            below the floor density ρ_P = c⁵/(ħG²).
# BH1 DIAG   Black holes as floor crossings: finite cores at ≤ ρ_P inside the horizon. Outside the horizon
#            the metric is GR's, so EHT shadows and LIGO ringdowns are unaffected (consistent, not discriminating).
# ============================================================
print("── §7: floor and black holes ───────────────")
rhoP = C_SI**5 / (HBAR * G_SI**2)
dens = {"nuclear matter (catalogue)": 10**np.mean(nuclear), "neutron-star core (≈ 8× nuclear)": 8 * 10**np.mean(nuclear),
        "BBN at T = 1 MeV (mass-equivalent)": (math.pi**2 / 30 * 10.75 * (1e6)**4) * 1.602176634e-19 / (1.97327e-7)**3 / C_SI**2}
mx = max(dens.values())
record("FL1", "TEST", "S-floor: all measured densities lie below the Planck floor density",
       f"ρ_P = {rhoP:.1e} kg/m³; highest measured ≈ {mx:.0e} kg/m³ ({math.log10(rhoP/mx):.0f} orders below)", rule="all < ρ_P",
       passed=bool(mx < rhoP), note="Consistent; no measured system comes near the floor, so this cannot discriminate yet.")
M_thr = math.sqrt(3 * C_SI**6 / (32 * math.pi * G_SI**3 * rhoP))       # Planck-density core radius = horizon radius
core_over_rs = lambda M: (3 * M / (4 * math.pi * rhoP))**(1 / 3) / (2 * G_SI * M / C_SI**2)
record("BH1", "DIAGNOSTIC", "Black holes as S-floor crossings: a Planck-density core sits inside the horizon",
       f"core inside horizon for M > {M_thr:.1e} kg; R_core/r_s = {core_over_rs(10 * MSUN):.0e} (10 M☉), "
       f"{core_over_rs(4.3e6 * MSUN):.0e} (Sgr A*)",
       note="Consistent with EHT and LIGO, which see only the exterior. Universe-seeding inside makes no exterior prediction unless "
            "a selection rule is added (e.g. 'physics favours making black holes'), which the hypothesis does not state.")
