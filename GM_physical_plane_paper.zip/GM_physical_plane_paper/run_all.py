"""Run the paper's test suite in order. Usage: python run_all.py"""
import os, sys, time
HERE = os.path.dirname(os.path.abspath(__file__))
ORDER = ["p01_setup", "p02_geometry", "p03_map", "p04_galactic_gradient", "p04b_clusters", "p05_vacuum_along_S",
         "p06_top_of_map", "p07_null_tests", "p08_redshift", "p09_summary"]
G = {}
for name in ORDER:
    f = os.path.join(HERE, "cells", name + ".py"); t0 = time.time()
    print(f"\n######## {name} ########", flush=True)
    exec(compile(open(f).read(), f, "exec"), G)
    print(f"######## {name} done in {time.time() - t0:.1f}s", flush=True)
